# src/database_module/database_manager.py
import queue
import threading
import logging
import os
import base64
from datetime import datetime

import pyodbc
import json

from src.utility.config_manager import get_config
from src.utility.logger import LoggerUtility

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class DBModule:
    def __init__(self):
        config = get_config()
        self.logger = LoggerUtility().get_logger(__name__)

        # Build connection string
        server = config.get('DATABASE', 'server')
        database = config.get('DATABASE', 'db_name', 'ZONE_DB')
        user = config.get('DATABASE', 'user', 'sa')
        password = config.get('DATABASE', 'password', 'root1234')

        self.connection_string = (
            r'DRIVER={ODBC Driver 17 for SQL Server};'
            f'SERVER={server};'
            f'DATABASE={database};'
            f'UID={user};'
            f'PWD={password};'
        )

        # Queue setup
        queue_size = config.getint('QUEUE', 'database_queue', 100)
        self.db_queue = queue.Queue(maxsize=queue_size)
        self.db_thread = threading.Thread(target=self._process_db_queue, daemon=True)
        self.db_thread.start()

        # Track ID management
        self.id_lock = threading.Lock()
        self.used_track_ids = set()
        self.last_track_id = self.initialize_track_ids_from_db()

        # ========== INITIALIZE STORAGE PATHS FROM DATABASE ==========
        self.base_path = self.get_base_path_from_config_details()
        self.base_image_path = os.path.join(self.base_path, "ZONE_IMAGES")
        self.base_video_path = os.path.join(self.base_path, "ZONE_VIDEOS")

        # Create directory structure
        self._create_storage_directories()
        # =================================================================

        # ROI/Zone cache - MODIFIED for multi-zone support
        self.zone_cache = {}
        self.zone_cache_lock = threading.Lock()
        print("Zone cache initialized for multi-zone support")

        # Add columns if needed
        self.add_columns()

        print("DBModule initialized successfully")

    def get_base_path_from_config_details(self):
        """Fetch BasePath from Config_Details table where ConfigKey = 'BasePath'"""
        try:
            with pyodbc.connect(self.connection_string) as conn:
                cursor = conn.cursor()
                query = """
                    SELECT Value FROM [ZONE_DB].[dbo].[Config_Details]
                    WHERE ConfigKey = 'BasePath'
                """
                cursor.execute(query)
                result = cursor.fetchone()

                if result and result[0]:
                    base_path = result[0].strip()
                    self.logger.info(f" BasePath from Config_Details: {base_path}")
                    return base_path
                else:
                    # Fallback to config.ini
                    config = get_config()
                    default_path = config.get('IMG_FOLDER_LOCATION', 'image_store_path', r"D:\ZONE_DATA")
                    # Remove ZONE_IMAGES if it exists in the path
                    if default_path.endswith("ZONE_IMAGES"):
                        default_path = os.path.dirname(default_path)
                    self.logger.warning(f" No BasePath in Config_Details, using config.ini: {default_path}")
                    return default_path

        except pyodbc.Error as e:
            self.logger.error(f" Database error fetching BasePath: {e}", exc_info=True)
            config = get_config()
            default_path = config.get('IMG_FOLDER_LOCATION', 'image_store_path', r"D:\ZONE_DATA")
            if default_path.endswith("ZONE_IMAGES"):
                default_path = os.path.dirname(default_path)
            self.logger.warning(f"️ Using config.ini BasePath: {default_path}")
            return default_path

    def update_video_path(self, video_path, event_id):
        """Update video path (Link) in BOTH Event_Details & Notification_Details tables"""
        try:
            with pyodbc.connect(self.connection_string) as conn:
                cursor = conn.cursor()

                # Update Event_Details
                query1 = """
                    UPDATE [ZONE_DB].[dbo].[Event_Details]
                    SET [Link] = ?
                    WHERE [Event_Id] = ?;
                """
                cursor.execute(query1, (video_path, event_id))

                # Update Notification_Details
                query2 = """
                    UPDATE [ZONE_DB].[dbo].[Notification_Details]
                    SET [Link] = ?
                    WHERE [Event_Id] = ?;
                """
                cursor.execute(query2, (video_path, event_id))

                conn.commit()
                return True

        except pyodbc.Error as e:
            self.logger.error(f"Database error updating video path in both tables: {e}", exc_info=True)
            return False

    def _create_storage_directories(self):
        """Create the folder structure: BasePath/ZONE_IMAGES and BasePath/ZONE_VIDEOS"""
        try:
            # Create base path
            if not os.path.exists(self.base_path):
                os.makedirs(self.base_path, exist_ok=True)
                self.logger.info(f"Created base directory: {self.base_path}")

            # Create ZONE_IMAGES
            if not os.path.exists(self.base_image_path):
                os.makedirs(self.base_image_path, exist_ok=True)
                self.logger.info(f" Created image directory: {self.base_image_path}")

            # Create ZONE_VIDEOS
            if not os.path.exists(self.base_video_path):
                os.makedirs(self.base_video_path, exist_ok=True)
                self.logger.info(f"Created video directory: {self.base_video_path}")

            print(f"\n Storage Structure:")
            print(f"   Base:   {self.base_path}")
            print(f"   Images: {self.base_image_path}")
            print(f"   Videos: {self.base_video_path}\n")

        except Exception as e:
            self.logger.error(f" Error creating storage directories: {e}", exc_info=True)
            raise

    # ==================== CAMERA QUERIES ====================

    def fetch_all_cameras(self):
        """Fetch all cameras from Camera_Details table"""
        try:
            with pyodbc.connect(self.connection_string) as conn:
                cursor = conn.cursor()
                query = """
                    SELECT [Camera_Id], [Camera_Name], [URL], [Camera_UserName], 
                           [Camera_IpAddress], [Camera_Password], [Camera_Port], [Camera_Substream]
                    FROM [ZONE_DB].[dbo].[Camera_Details]
                    ORDER BY [Camera_Id]
                """
                cursor.execute(query)
                columns = [column[0] for column in cursor.description]
                cameras = [dict(zip(columns, row)) for row in cursor.fetchall()]
                print(f"Fetched {len(cameras)} cameras from database")
                return cameras
        except pyodbc.Error as e:
            self.logger.error(f"Database error while fetching cameras: {e}", exc_info=True)
            return []

    def get_camera_id_by_name(self, camera_name):
        """Fetch Camera_Id from Camera_Details using Camera_Name"""
        try:
            with pyodbc.connect(self.connection_string) as conn:
                cursor = conn.cursor()
                query = "SELECT Camera_Id FROM [ZONE_DB].[dbo].[Camera_Details] WHERE Camera_Name = ?"
                cursor.execute(query, camera_name)
                result = cursor.fetchone()
                return result[0] if result else None
        except pyodbc.Error as e:
            self.logger.error(f"Error fetching Camera_Id for '{camera_name}': {e}", exc_info=True)
            return None

    # ==================== ROI QUERIES ====================

    def get_roi_by_camera_id(self, camera_id):
        """Fetch all ROI points from Camera_ROI table"""
        try:
            with pyodbc.connect(self.connection_string) as conn:
                cursor = conn.cursor()
                query = "SELECT Points FROM [ZONE_DB].[dbo].[Camera_ROI] WHERE CameraId = ?"
                cursor.execute(query, camera_id)
                results = cursor.fetchall()
                return [json.loads(row[0]) for row in results] if results else []
        except Exception as e:
            self.logger.error(f"Error fetching ROIs for Camera {camera_id}: {e}", exc_info=True)
            return []

    def get_all_zones_for_camera(self, camera_id):
        """Fetch ALL zones (Name + Points) for a camera"""
        with self.zone_cache_lock:
            if camera_id in self.zone_cache:
                return self.zone_cache[camera_id]

        try:
            with pyodbc.connect(self.connection_string) as conn:
                cursor = conn.cursor()
                query = "SELECT [Id], [Name], [Points] FROM [ZONE_DB].[dbo].[Camera_ROI] WHERE CameraId = ? ORDER BY [Id]"
                cursor.execute(query, camera_id)
                results = cursor.fetchall()

                zones = []
                for row in results:
                    zone_id, zone_name, points_json = row
                    try:
                        points = json.loads(points_json) if points_json else []
                        zones.append({
                            'id': zone_id,
                            'name': zone_name.strip() if zone_name else f"Zone_{zone_id}",
                            'points': points
                        })
                    except Exception as e:
                        self.logger.error(f"Error parsing zone {zone_id}: {e}")

                with self.zone_cache_lock:
                    self.zone_cache[camera_id] = zones

                return zones
        except pyodbc.Error as e:
            self.logger.error(f"Error fetching zones for Camera {camera_id}: {e}", exc_info=True)
            return []

    def clear_zone_cache(self, camera_id=None):
        """Clear zone cache"""
        with self.zone_cache_lock:
            if camera_id is not None:
                self.zone_cache.pop(camera_id, None)
            else:
                self.zone_cache.clear()

    # ==================== ZONE POLICY QUERIES ====================

    def check_zone_policy(self, camera_id):
        """Check if Event=1 in ZonePolicy table"""
        try:
            with pyodbc.connect(self.connection_string) as conn:
                cursor = conn.cursor()
                query = "SELECT Event FROM [ZONE_DB].[dbo].[ZonePolicy] WHERE Cam_Id = ? AND Event = 1"
                cursor.execute(query, camera_id)
                return cursor.fetchone() is not None
        except pyodbc.Error as e:
            self.logger.error(f"Error checking ZonePolicy for Camera {camera_id}: {e}", exc_info=True)
            return False

    def get_enabled_classes_for_camera(self, camera_id):
        """Fetch enabled object types for camera from ZonePolicy"""
        try:
            with pyodbc.connect(self.connection_string) as conn:
                cursor = conn.cursor()
                query = "SELECT [Type] FROM [ZONE_DB].[dbo].[ZonePolicy] WHERE [Cam_Id] = ? AND [Event] = 1"
                cursor.execute(query, camera_id)
                results = cursor.fetchall()
                return [row[0].strip().lower() for row in results if row[0]]
        except pyodbc.Error as e:
            self.logger.error(f"Error fetching enabled classes for Camera {camera_id}: {e}", exc_info=True)
            return []

    def get_all_camera_enabled_classes(self):
        """Fetch enabled classes for ALL cameras from ZonePolicy"""
        try:
            with pyodbc.connect(self.connection_string) as conn:
                cursor = conn.cursor()
                query = "SELECT [Cam_Id], [Type] FROM [ZONE_DB].[dbo].[ZonePolicy] WHERE [Event] = 1"
                cursor.execute(query)
                results = cursor.fetchall()

                camera_classes = {}
                for row in results:
                    cam_id, obj_type = row[0], row[1].strip().lower() if row[1] else None
                    if obj_type:
                        camera_classes.setdefault(cam_id, []).append(obj_type)
                return camera_classes
        except pyodbc.Error as e:
            self.logger.error(f"Error fetching all camera enabled classes: {e}", exc_info=True)
            return {}

    def add_columns(self):
        """Ensure Gender and Object_Sub_Type columns exist"""
        try:
            with pyodbc.connect(self.connection_string) as conn:
                cursor = conn.cursor()

                # Add columns to Event_Details
                cursor.execute("""
                    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
                                   WHERE TABLE_NAME = 'Event_Details' AND COLUMN_NAME = 'Gender')
                    BEGIN
                        ALTER TABLE [dbo].[Event_Details] ADD Gender VARCHAR(50) NULL
                    END
                """)
                cursor.execute("""
                    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
                                   WHERE TABLE_NAME = 'Event_Details' AND COLUMN_NAME = 'Object_Sub_Type')
                    BEGIN
                        ALTER TABLE [dbo].[Event_Details] ADD Object_Sub_Type VARCHAR(50) NULL
                    END
                """)

                # Add columns to Notification_Details
                cursor.execute("""
                    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
                                   WHERE TABLE_NAME = 'Notification_Details' AND COLUMN_NAME = 'Gender')
                    BEGIN
                        ALTER TABLE [dbo].[Notification_Details] ADD Gender VARCHAR(50) NULL
                    END
                """)
                cursor.execute("""
                    IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
                                   WHERE TABLE_NAME = 'Notification_Details' AND COLUMN_NAME = 'Object_Sub_Type')
                    BEGIN
                        ALTER TABLE [dbo].[Notification_Details] ADD Object_Sub_Type VARCHAR(50) NULL
                    END
                """)
                conn.commit()
        except pyodbc.Error as e:
            self.logger.error(f"Error adding columns: {e}", exc_info=True)

    # ==================== TRACK ID MANAGEMENT ====================

    def initialize_track_ids_from_db(self):
        """Initialize next track ID"""
        try:
            with pyodbc.connect(self.connection_string) as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT  Event_Id FROM [ZONE_DB].[dbo].[Event_Details] order by Event_Time desc")
                used_track_ids = set()
                for row in cursor.fetchall():
                    try:
                        track_id = int(row[0].split('_')[-1]) if '_' in row[0] else int(row[0])
                        used_track_ids.add(track_id)
                    except (ValueError, IndexError):
                        continue
                return max(used_track_ids) + 1 if used_track_ids else 1
        except pyodbc.Error as e:
            self.logger.error(f"Error initializing track IDs: {e}", exc_info=True)
            return 1


    def generate_composite_track_id(self, camera_name, timestamp, track_id):
        """Generate composite track ID: CameraName+UnixTimestamp+TrackID"""
        timestamp_str = str(int(timestamp.timestamp()))
        safe_camera_name = camera_name.replace(" ", "_").replace(":", "_")
        return f"{safe_camera_name}_{track_id}"

    # ==================== IMAGE/VIDEO PATH MANAGEMENT ====================

    def save_image_to_disk(self, image_base64, camera_name, timestamp):
        """Save image to disk: ZONE_IMAGES/DD-MM-YYYY/camera_name/image.jpg"""
        try:
            image_data = base64.b64decode(image_base64)
            date_str = timestamp.strftime('%d-%m-%Y')
            safe_camera_name = camera_name.replace(" ", "_").replace(":", "_").replace("\\", "_").replace("/", "_")

            dir_path = os.path.join(self.base_image_path, date_str, safe_camera_name)
            os.makedirs(dir_path, exist_ok=True)

            timestamp_str = timestamp.strftime('%Y%m%d_%H%M%S_%f')
            filename = f"{timestamp_str}.jpg"
            full_path = os.path.join(dir_path, filename)

            with open(full_path, 'wb') as f:
                f.write(image_data)

            # Store relative path in database
            relative_path = os.path.join(date_str, safe_camera_name, filename)
            self.logger.debug(f" Image saved: {full_path}")
            return relative_path

        except Exception as e:
            self.logger.error(f"Error saving image for '{camera_name}': {e}", exc_info=True)
            return None

    def get_full_image_path(self, relative_path):
        """Convert relative path to full path"""
        return os.path.join(self.base_image_path, relative_path) if relative_path else None

    def get_full_video_path(self, relative_path):
        """Convert relative video path to full path"""
        return os.path.join(self.base_video_path, relative_path) if relative_path else None

    # ==================== EVENT INSERTION ====================

    def save_to_db_queue(self, object_id, image_base64, timestamp, object_type,
                         object_sub_type, camera_name, gender=None, video_path=None, zone_name=None):
        """Add an event to the database queue"""
        try:
            self.db_queue.put((
                object_id, image_base64, timestamp, object_type,
                object_sub_type, camera_name, gender, video_path, zone_name
            ), timeout=1.0)
        except queue.Full:
            self.logger.error(f"Database queue full - Event dropped: {object_type} from {camera_name}")

    def _process_db_queue(self):
        """Process the database queue"""
        while True:
            try:
                item = self.db_queue.get(timeout=1.0)
                self._save_to_db(item)
                self.db_queue.task_done()
            except queue.Empty:
                continue
            except Exception as e:
                self.logger.error(f"Error in database queue: {e}", exc_info=True)

    def _save_to_db(self, item):
        """Save event to Event_Details and Notification_Details"""
        try:
            (object_id, image_base64, timestamp, object_type, object_sub_type,
             camera_name, gender, video_path, zone_name) = item

            camera_id = self.get_camera_id_by_name(camera_name)
            if camera_id is None:
                self.logger.error(f"No Camera_Id for '{camera_name}' - Event not saved")
                return

            zone_name = zone_name or "Default Zone"
            todays_date = datetime.today().strftime('%d-%m-%Y')
            # video_path=f"{todays_date}\\{camera_name}\\{camera_name}_{object_id}.ts"
            video_path = None

            # Save image
            image_relative_path = self.save_image_to_disk(image_base64, camera_name, timestamp)
            if image_relative_path is None:
                self.logger.error(f"Failed to save image - Event not saved")
                return

            # Generate event ID

            event_id = self.generate_composite_track_id(camera_name, timestamp, object_id)

            # Insert into Event_Details
            with pyodbc.connect(self.connection_string, autocommit=True) as conn:
                cursor = conn.cursor()

                insert_event_query = """
                    INSERT INTO [ZONE_DB].[dbo].[Event_Details]
                    ([Event_Id], [Img], [Event_Time], [Object_Type], [Object_Sub_Type], 
                     [Camera_Id], [Camera_Name], [Link], [Gender], [Zone_Name])
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """
                cursor.execute(insert_event_query,
                               event_id, image_relative_path, timestamp, object_type,
                               object_sub_type, camera_id, camera_name,
                               video_path, gender, zone_name)

                self.logger.info(f" Event saved - ID: {event_id}, Zone: {zone_name}")

                # Insert into Notification_Details if policy enabled
                if self.check_zone_policy(camera_id):
                    insert_notification_query = """
                        INSERT INTO [ZONE_DB].[dbo].[Notification_Details]
                        ([Event_Id], [Img], [Event_Time], [Object_Type], [Camera_Id], 
                         [Camera_Name], [Link], [Gender], [Object_Sub_Type], [Zone_Name],
                         [Ack_Message], [Ack_By], [Ack_Time])
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, NULL)
                    """
                    cursor.execute(insert_notification_query,
                                   event_id, image_relative_path, timestamp, object_type,
                                   camera_id, camera_name, video_path, gender,
                                   object_sub_type, zone_name)

        except pyodbc.Error as e:
            self.logger.error(f"Database write error: {e}", exc_info=True)
        except Exception as e:
            self.logger.error(f"Unexpected error in _save_to_db: {e}", exc_info=True)