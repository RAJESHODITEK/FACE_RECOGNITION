# src/camera_module/camera_manager.py
import logging
import time
from queue import Queue, Empty
import cv2
import numpy as np
import av
from threading import Lock
from src.utility.config_manager import get_config


class CameraManager:
    def __init__(self, rtsp_url, idx):
        config = get_config()

        self.rtsp_url = rtsp_url
        self.cam_idx = idx

        # Get queue sizes from config
        frame_queue_size = config.getint('QUEUE', 'cam_queue', 3)
        detection_queue_size = config.getint('QUEUE', 'detection_queue', 2)
        tracking_queue_size = config.getint('QUEUE', 'track_queue', 3)

        self.frame_queue = Queue(maxsize=frame_queue_size)
        self.detection_queue = Queue(maxsize=detection_queue_size)
        self.tracking_queue = Queue(maxsize=tracking_queue_size)
        self.database_queue = Queue(maxsize=detection_queue_size)

        # PyAV container and stream variables
        self.container = None
        self.video_stream = None
        self.reconnect_lock = Lock()

        # Get connection parameters from config
        self.connection_timeout = config.getint('CAMERA', 'connection_timeout', 5)
        self.read_timeout = config.getint('CAMERA', 'read_timeout', 10)
        self.max_consecutive_failures = config.getint('CAMERA', 'max_consecutive_failures', 3)
        self.rtsp_transport = config.get('CAMERA', 'rtsp_transport', 'tcp')
        self.max_delay = config.getint('CAMERA', 'max_delay', 500000)
        self.buffer_size = config.getint('CAMERA', 'buffer_size', 1024000)
        self.probesize = config.getint('CAMERA', 'probesize', 32)
        self.analyzeduration = config.getint('CAMERA', 'analyzeduration', 1000000)

        # Default video properties from config
        self.default_width = config.getint('CAMERA', 'default_width', 1280)
        self.default_height = config.getint('CAMERA', 'default_height', 720)
        self.default_fps = config.getint('CAMERA', 'default_fps', 25)

        # Reconnection settings from config
        self.reconnect_delay_base = config.getfloat('CAMERA', 'reconnect_delay_base', 0.2)
        self.reconnect_delay_multiplier = config.getfloat('CAMERA', 'reconnect_delay_multiplier', 0.3)
        self.max_reconnect_attempts = config.getint('CAMERA', 'max_reconnect_attempts', 3)

        # Sleep intervals from config
        self.failed_read_sleep = config.getfloat('CAMERA', 'failed_read_sleep', 0.1)
        self.reconnect_failure_sleep = config.getfloat('CAMERA', 'reconnect_failure_sleep', 1.0)
        self.frame_empty_sleep = config.getfloat('CAMERA', 'frame_empty_sleep', 0.5)

        # Initialize PyAV connection
        self._initialize_connection()


    def _initialize_connection(self):
        """Initialize PyAV container and video stream"""
        try:
            # PyAV connection options for faster reconnection
            options = {
                'rtsp_transport': self.rtsp_transport,
                'stimeout': str(self.connection_timeout * 1000000),
                'max_delay': str(self.max_delay),
                'buffer_size': str(self.buffer_size),
                'fflags': 'nobuffer',
                'flags': 'low_delay',
                'probesize': str(self.probesize),
                'analyzeduration': str(self.analyzeduration),
            }

            # Open container with timeout and options
            self.container = av.open(
                self.rtsp_url,
                mode='r',
                options=options,
                timeout=self.connection_timeout
            )

            # Get video stream
            self.video_stream = self.container.streams.video[0]


            return True

        except Exception as e:
            self.container = None
            self.video_stream = None
            return False

    def _close_connection(self):
        """Safely close PyAV connection"""
        try:
            if self.container:
                self.container.close()
        except Exception as e:
            print(f"Error closing PyAV container: {e}")
        finally:
            self.container = None
            self.video_stream = None

    def read_frame(self):
        """Main frame reading loop with PyAV"""
        failed_read_count = 0

        while True:
            try:
                # Check if connection is available
                if not self.container or not self.video_stream:
                    if not self.reconnect():
                        time.sleep(self.frame_empty_sleep)
                        continue

                # Read frame using PyAV
                frame = self._read_single_frame()

                if frame is not None:
                    failed_read_count = 0  # Reset on successful read

                    # Add frame to queue (non-blocking)
                    try:
                        self.frame_queue.put_nowait(frame)
                    except:
                        pass  # Skip if queue is full

                else:
                    failed_read_count += 1
                    logging.warning(
                        f"Failed to read frame (attempt {failed_read_count}/{self.max_consecutive_failures})")

                    if failed_read_count >= self.max_consecutive_failures:
                        logging.error("Multiple consecutive frame read failures - initiating reconnect")
                        if not self.reconnect():
                            time.sleep(self.reconnect_failure_sleep)
                        failed_read_count = 0
                    else:
                        time.sleep(self.failed_read_sleep)

            except Exception as e:
                logging.error(f"Error in frame reading loop: {e}")
                failed_read_count += 1

                if failed_read_count >= self.max_consecutive_failures:
                    self.reconnect()
                    failed_read_count = 0

                time.sleep(self.failed_read_sleep)

    def _read_single_frame(self):
        """Read a single frame using PyAV"""
        try:
            if not self.container or not self.video_stream:
                return None

            # Decode next frame with timeout handling
            for packet in self.container.demux(self.video_stream):
                for frame in packet.decode():
                    if frame:
                        # Convert PyAV frame to numpy array (BGR format for OpenCV compatibility)
                        img_array = frame.to_ndarray(format='bgr24')

                        # Validate frame
                        if img_array is not None and img_array.size > 0:
                            return img_array

            return None

        except av.AVError as e:
            logging.warning(f"PyAV decode error: {e}")
            return None
        except Exception as e:
            logging.error(f"Unexpected error reading PyAV frame: {e}")
            return None

    def reconnect(self):
        """Fast reconnection using PyAV"""
        with self.reconnect_lock:

            # Close existing connection
            self._close_connection()

            # Small delay before reconnection
            time.sleep(self.reconnect_delay_base)

            # Attempt to re-establish connection
            for attempt in range(self.max_reconnect_attempts):
                try:
                    if self._initialize_connection():
                        print(f"Camera {self.cam_idx} reconnected successfully to {self.rtsp_url} using PyAV")
                        return True
                    else:

                        time.sleep(self.reconnect_delay_multiplier * (attempt + 1))

                except Exception as e:
                    logging.error(f"PyAV reconnection attempt {attempt + 1} failed: {e}")
                    time.sleep(self.reconnect_delay_multiplier * (attempt + 1))

            logging.error(f"All PyAV reconnection attempts failed for camera {self.cam_idx}")
            return False

    def is_connected(self):
        """Check if PyAV connection is active"""
        return self.container is not None and self.video_stream is not None

    def get_stream_info(self):
        """Get current stream information"""
        if not self.is_connected():
            return {"connected": False}

        try:
            return {
                "connected": True,
                "width": self.video_stream.width,
                "height": self.video_stream.height,
                "fps": float(self.video_stream.average_rate) if self.video_stream.average_rate else "Unknown",
                "codec": self.video_stream.codec_context.name if self.video_stream.codec_context else "Unknown"
            }
        except Exception as e:
            logging.warning(f"Error getting stream info: {e}")
            return {"connected": False, "error": str(e)}

    def release(self):
        """Release PyAV resources"""
        self._close_connection()

    def __del__(self):
        """Cleanup on object destruction"""
        try:
            self.release()
        except:
            pass