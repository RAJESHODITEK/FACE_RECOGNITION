import threading
import logging
from src.camera_module.camera_manager import CameraManager


class MultiCamCameraManager:
    def __init__(self, rtsp_urls: list):
        self.rtsp_urls = rtsp_urls
        self.camera_managers = {}  # ✅ Use dict for easier access by ID
        self.threads = []

    def start_all_cameras(self):
        for idx, url in enumerate(self.rtsp_urls):
            try:
                camera = CameraManager(rtsp_url=url, idx=idx)
                self.camera_managers[idx] = camera  # ✅ Store as id: object

                thread = threading.Thread(
                    target=camera.read_frame,
                    name=f"CameraThread-{idx}",
                    daemon=True
                )
                thread.start()
                self.threads.append(thread)

            except Exception as e:
                logging.error(f"Failed to initialize camera {url}: {e}")

        # Optional: Only join if you want blocking behavior here
        # for thread in self.threads:
        #     thread.join()

    def stop_all_cameras(self):
        for cam_id, camera in self.camera_managers.items():
            camera.release()


    def get_camera_managers(self):
        return self.camera_managers
