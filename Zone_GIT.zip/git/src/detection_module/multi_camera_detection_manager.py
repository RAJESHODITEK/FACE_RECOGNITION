# Modified src/detection_module/multi_camera_detection_manager.py
import threading
import logging
from src.detection_module.detection_manager import DetectionManager
from src.camera_module.camera_manager import CameraManager
from ultralytics import YOLO
import torch

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class MultiCameraDetectionManager:
    def __init__(self, camera_manager, model_path="yolov11m.pt", roi_dict=None, camera_names=None):
        self.camera_manager = camera_manager
        self.model_path = model_path
        self.detection_threads = []
        self.detection_managers = {}  # Store detection managers for ROI updates
        self.shared_model = None
        self.roi_dict = roi_dict or {}
        self.camera_names = camera_names or {}

        # Initialize the shared YOLO model once
        self._initialize_shared_model()

    def _initialize_shared_model(self):
        """Initialize a single YOLO model to be shared across all cameras"""
        try:
            device = 'cuda' if torch.cuda.is_available() else 'cpu'


            self.shared_model = YOLO(self.model_path)
            self.shared_model.fuse()  # Optional, for speed

            if device == 'cuda':
                self.shared_model.half()


        except Exception as e:
            logging.error(f"Failed to initialize shared YOLO model: {e}")
            raise e

    def start(self):
        """Create and start a DetectionManager thread for each camera using the shared model"""
        if self.shared_model is None:
            logging.error(" Shared model not initialized. Cannot start detection.")
            return

        # Create and start a DetectionManager and thread for each camera
        for cam_id, cam_obj in self.camera_manager.items():
            camera_name = self.camera_names.get(cam_id, f"Camera_{cam_id}")
            roi = self.roi_dict.get(camera_name)

            # Pass the shared model to each DetectionManager
            detection_manager = DetectionManager(
                cam_obj,
                shared_model=self.shared_model,  # ✅ Pass shared model
                model_path=self.model_path,
                roi=roi,
                camera_name=camera_name  # Pass camera name for identification
            )

            # Store detection manager for ROI updates
            self.detection_managers[camera_name] = detection_manager

            detection_thread = threading.Thread(
                target=detection_manager.detect,
                daemon=True,
                name=f"DetectionThread-{cam_id}"
            )
            detection_thread.start()

            self.detection_threads.append((cam_id, detection_thread))


        # Wait for all threads (they run indefinitely)
        for cam_id, detection_thread in self.detection_threads:
            detection_thread.join()

    def update_camera_roi(self, camera_name, new_roi):
        """Update ROI for a specific camera dynamically"""
        if camera_name in self.detection_managers:
            self.detection_managers[camera_name].update_roi(new_roi)

            return True
        else:
            logging.error(f"Camera {camera_name} not found in detection managers")
            return False

    def get_shared_model(self):
        """Get the shared YOLO model instance"""
        return self.shared_model

    def get_detection_threads(self):
        """Get list of detection threads"""
        return self.detection_threads

    def get_detection_managers(self):
        """Get dictionary of detection managers"""
        return self.detection_managers