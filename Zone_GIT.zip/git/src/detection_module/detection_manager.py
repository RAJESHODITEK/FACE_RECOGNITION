# detection_manager.py
import time
import cv2
import torch
import numpy as np
from ultralytics import YOLO
from queue import Full, Empty
import logging
from collections import defaultdict
from src.utility.enabled_classes import is_enabled
from src.utility.confidence_manager import get_confidence_for_class
from src.utility.point_in_polygon import point_in_polygon
import threading
from src.utility.config_manager import get_config
from threading import Event

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class DetectionManager:
    """
    Optimized detection loop using Ultralytics YOLO model.
    Improvements:
      - Vectorized class/confidence filtering using numpy
      - Minimized frame copies
      - Limited queue purging to keep memory/latency bounded
      - Exposes stop() method via event for graceful shutdown
    """

    def __init__(self, Camera_manager, shared_model=None, model_path="yolo11m.pt",
                 roi=None, camera_name=None, db_module=None):
        config = get_config()
        self.logger = logging.getLogger(self.__class__.__name__)

        # Device
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'

        # Camera and queues
        self.obj_Camera_manager = Camera_manager
        self.detection_queue = self.obj_Camera_manager.detection_queue
        self.frame_queue = self.obj_Camera_manager.frame_queue
        self.cam_idx = Camera_manager.cam_idx

        # ROI & camera naming
        self.roi = roi or []
        self.camera_name = camera_name or f"Camera_{Camera_manager.cam_idx}"
        self.db_module = db_module

        # Model setup (reuse or load)
        if shared_model is not None:
            self.model = shared_model
        else:
            self.model = YOLO(model_path)
            try:
                self.model.fuse()
            except Exception:
                # Some models may not support fuse; continue anyway
                self.logger.debug("Model fuse failed or not applicable")

            if self.device == 'cuda':
                try:
                    self.model.to(self.device)
                    # keep half precision if available
                    self.model.half()
                except Exception as e:
                    self.logger.warning(f"Failed to move model to CUDA or half(): {e}")

        # Detection parameters
        self.frame_skip_count = config.getint('DETECTION', 'frame_skip')
        self.current_frame = 0
        self.conf_threshold = config.getfloat('DETECTION', 'yolo_conf')
        self.iou_threshold = config.getfloat('DETECTION', 'yolo_iou')
        self.nms_iou_threshold = config.getfloat('DETECTION', 'yolo_iou')
        self.max_detections = config.getint('DETECTION', 'max_detections')
        self.batch_size = config.getint('DETECTION', 'batch_size')
        self.imgsz = config.getint('DETECTION', 'size')

        # Timing / performance
        self.inference_sleep = config.getfloat('DETECTION', 'inference_sleep')
        self.frame_wait_sleep = config.getfloat('DETECTION', 'frame_wait_sleep')
        self.fps_log_interval = config.getint('DETECTION', 'fps_log_interval')
        self.cuda_cache_clear_interval = config.getint('DETECTION', 'cuda_cache_clear_interval')

        # ROI handling
        self.roi_update_flag = False
        self.roi_lock = threading.Lock()
        self.pixel_rois = []
        self.roi_cache_update_interval = config.getint('ROI', 'cache_update_interval')

        # Queue sizing
        self.max_queue_size = config.getint('QUEUE', 'detection_queue')

        # Precompute enabled classes for camera and keep as numpy array for fast masking
        self.enabled_classes_cache = self._get_enabled_classes()
        # also keep as numpy list for np.in1d usage (faster than Python loop for many detections)
        self._enabled_array = np.array(list(self.enabled_classes_cache), dtype=np.int32) if self.enabled_classes_cache else np.array([], dtype=np.int32)

        # Statistics
        self.fps_counter = 0
        self.fps_start_time = time.time()

        # Control
        self.stop_event = Event()

    def _get_enabled_classes(self):
        """Pre-compute enabled classes for this camera (returns a Python set)"""
        enabled = set()
        # COCO classes typically 0..79
        for cls_id in range(80):
            if is_enabled(cls_id, self.cam_idx):
                enabled.add(cls_id)
        print(f"[{self.camera_name}] Enabled classes: {enabled}")
        return enabled

    def stop(self):
        """Signal the detection loop to stop"""
        self.stop_event.set()

    def update_roi(self, new_roi):
        """Update ROI points (percentages) and clear pixel cache"""
        with self.roi_lock:
            self.roi = new_roi
            self.pixel_rois = []
            self.roi_update_flag = True

            for idx, roi in enumerate(new_roi):
                print(f"[{self.camera_name}]   ROI {idx}: {len(roi)} points")

    def _update_pixel_rois(self, frame_shape):
        """
        Convert percentage ROIs to pixel coordinates (cached).
        frame_shape: (h, w, ...)
        """
        if self.pixel_rois and not self.roi_update_flag:
            return self.pixel_rois

        with self.roi_lock:
            h, w = frame_shape[:2]

            pixel_rois = []
            if self.roi:
                for roi in self.roi:
                    if not roi:
                        continue
                    pixel_rois.append([(int(point['x'] * w / 100), int(point['y'] * h / 100)) for point in roi])

            elif self.db_module:
                camera_id = self.db_module.get_camera_id_by_name(self.camera_name)
                if camera_id is not None:
                    rois = self.db_module.get_roi_by_camera_id(camera_id)
                    for roi in (rois or []):
                        if not roi:
                            continue
                        pixel_rois.append([(int(point['x'] * w / 100), int(point['y'] * h / 100)) for point in roi])

            self.pixel_rois = pixel_rois
            self.roi_update_flag = False

        return self.pixel_rois

    def _filter_detections(self, boxes, confidences, classes, frame_shape):
        """
        Vectorized filtering for class & confidence, followed by ROI checks.
        boxes: np.ndarray shape (N,4) in xyxy pixel coords relative to original frame
        confidences: np.ndarray shape (N,)
        classes: np.ndarray shape (N,) ints
        """
        if boxes.size == 0:
            return np.empty((0, 4), dtype=np.int32), np.empty((0,), dtype=float), np.empty((0,), dtype=int)

        # 1) class filter using enabled classes (vectorized)
        if self._enabled_array.size > 0:
            # np.in1d is efficient for this use
            class_mask = np.in1d(classes, self._enabled_array)
        else:
            # no classes enabled -> empty
            return np.empty((0, 4), dtype=np.int32), np.empty((0,), dtype=float), np.empty((0,), dtype=int)

        if not np.any(class_mask):
            # print(f"[{self.camera_name}] All detections filtered by class")
            return np.empty((0, 4), dtype=np.int32), np.empty((0,), dtype=float), np.empty((0,), dtype=int)

        # 2) threshold per-class (vectorized by building thresholds array)
        # Build a thresholds array for each class in `classes` (only for candidates)
        candidate_idxs = np.where(class_mask)[0]
        candidate_classes = classes[candidate_idxs]
        thresholds = np.array([get_confidence_for_class(int(c)) for c in candidate_classes], dtype=float)
        candidate_confs = confidences[candidate_idxs]
        conf_mask = candidate_confs >= thresholds

        if not np.any(conf_mask):
            print(f"[{self.camera_name}] All detections filtered by confidence")
            return np.empty((0, 4), dtype=np.int32), np.empty((0,), dtype=float), np.empty((0,), dtype=int)

        # Keep only class+confidence-passing indices
        keep_candidate_idxs = candidate_idxs[conf_mask]

        # 3) ROI filter (loop only over reduced set)
        pixel_rois = self._update_pixel_rois(frame_shape)
        if pixel_rois:
            kept = []
            for idx in keep_candidate_idxs:
                x1, y1, x2, y2 = boxes[idx]
                cx = (x1 + x2) / 2.0
                cy = (y1 + y2) / 2.0

                inside = False
                for pixel_roi in pixel_rois:
                    if len(pixel_roi) >= 3 and point_in_polygon(cx, cy, pixel_roi):
                        inside = True
                        break
                if inside:
                    kept.append(idx)
            keep_idxs = np.array(kept, dtype=int) if kept else np.array([], dtype=int)
            if keep_idxs.size == 0:
                print(f"[{self.camera_name}] All detections filtered by ROI")
                return np.empty((0, 4), dtype=np.int32), np.empty((0,), dtype=float), np.empty((0,), dtype=int)
        else:
            # no ROI defined: keep all candidate indices
            keep_idxs = keep_candidate_idxs

        final_boxes = boxes[keep_idxs].astype(np.int32)
        final_confs = confidences[keep_idxs]
        final_classes = classes[keep_idxs].astype(int)

        print(f"[{self.camera_name}] Filtered -> kept {len(keep_idxs)} / {len(boxes)}")
        return final_boxes, final_confs, final_classes

    def detect(self):
        """
        Main detection loop. This is designed to be run in its own thread.
        """
        while not self.stop_event.is_set():
            try:
                # If no frames available, sleep a little
                try:
                    # Small blocking wait so thread is responsive but not busy-waiting
                    frame = self.frame_queue.get(timeout=self.frame_wait_sleep)
                except Empty:
                    continue

                # Frame skipping logic
                self.current_frame += 1
                if self.current_frame % self.frame_skip_count != 0:
                    # drop frame (we already dequeued it)
                    continue

                # We will keep original frame for downstream tracking - only copy once when needed
                original_frame = frame  # avoid extra copy until we put into detection queue

                # Keep detection queue bounded: if it's full or nearly full, drop oldest entries
                # Instead of clearing entire queue, pop a small number of oldest items
                try:
                    while self.detection_queue.qsize() >= self.max_queue_size:
                        # remove a single oldest item; this keeps backlog under control
                        _ = self.detection_queue.get_nowait()
                        print(f"[{self.camera_name}] Dropped oldest detection item to relieve queue pressure")
                except Empty:
                    pass

                # Run inference (Ultralytics handles preprocessing). Use torch.no_grad() to reduce overhead.
                with torch.no_grad():
                    # model.predict returns a list-like; we request at most 1 image here
                    # Use device param so model avoids extra CPU/GPU transfers inside.
                    results = self.model.predict(
                        original_frame,
                        conf=self.conf_threshold,
                        iou=self.nms_iou_threshold,
                        device=self.device,
                        verbose=False,
                        half=(self.device == 'cuda'),
                        imgsz=self.imgsz,
                        agnostic_nms=False,
                        max_det=self.max_detections,
                    )

                if not results or len(results) == 0:
                    # No detections
                    detections = []
                else:
                    r = results[0]
                    # If no boxes attribute or it's empty, skip
                    if getattr(r, "boxes", None) is None or len(r.boxes) == 0:
                        detections = []
                    else:
                        # Convert to numpy arrays once (single sync)
                        boxes = r.boxes.xyxy.cpu().numpy()  # shape (N,4)
                        confidences = r.boxes.conf.cpu().numpy()  # shape (N,)
                        classes = r.boxes.cls.cpu().numpy().astype(int)  # shape (N,)


                        # Filter detections with vectorized class/conf + ROI checks
                        boxes, confidences, classes = self._filter_detections(boxes, confidences, classes, original_frame.shape)

                        detections = []
                        if boxes.shape[0] > 0:
                            for box, conf, cls in zip(boxes, confidences, classes):
                                x1, y1, x2, y2 = map(int, box)
                                detections.append({
                                    "box": [x1, y1, x2, y2],
                                    "conf": float(conf),
                                    "cls": int(cls)
                                })

                # Push to detection_queue if space available
                if len(detections) == 0:
                    # still push an empty detection so downstream knows a frame arrived (optional)
                    payload = {"frame": original_frame.copy(), "detections": []}
                else:
                    payload = {"frame": original_frame.copy(), "detections": detections}

                try:
                    # Non-blocking put to avoid deadlocks. If full, drop this payload.
                    self.detection_queue.put(payload, block=False)

                except Full:
                    self.logger.warning(f"[{self.camera_name}] Detection queue full ({self.max_queue_size}) - dropping payload")

                # FPS logging periodically
                self.fps_counter += 1
                if self.fps_counter % self.fps_log_interval == 0:
                    elapsed = time.time() - self.fps_start_time
                    fps = self.fps_log_interval / elapsed if elapsed > 0 else 0.0
                    self.logger.info(f"[{self.camera_name}] Detection FPS ~ {fps:.2f}")
                    self.fps_start_time = time.time()

                # CUDA cache clearing occasionally
                if self.device == 'cuda' and (self.current_frame % self.cuda_cache_clear_interval == 0):
                    try:
                        torch.cuda.empty_cache()
                        self.logger.debug(f"[{self.camera_name}] Cleared CUDA cache")
                    except Exception as e:
                        self.logger.debug(f"[{self.camera_name}] CUDA cache clear failed: {e}")

                # Small sleep to yield CPU (keeps loop cooperative)
                if self.inference_sleep and self.inference_sleep > 0:
                    time.sleep(self.inference_sleep)

            except Exception as e:
                self.logger.error(f"[{self.camera_name}] Detection error: {e}", exc_info=True)
                # small sleep to avoid tight error loop
                time.sleep(0.1)

        self.logger.info(f"[{self.camera_name}] Detection thread stopped")

