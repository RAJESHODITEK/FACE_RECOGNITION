from collections import defaultdict
import time

class ObserverModule:
    def __init__(self):
        self.track_history = defaultdict(list)
        self.max_history_length = 10
        self.yolo_to_sequential_id = {}
        self.next_sequential_id = 1
        self.used_track_ids = set()
        self.sequential_track_history = defaultdict(list)
        self.active_tracks = set()
        self.last_seen = defaultdict(float)
        self.track_timeout = 4.0

    def get_next_available_track_id(self):
        while self.next_sequential_id in self.used_track_ids:
            self.next_sequential_id += 1
        current_id = self.next_sequential_id
        self.used_track_ids.add(current_id)
        self.next_sequential_id += 1
        return current_id

    def get_sequential_track_id(self, yolo_track_id):
        current_Time = time.time()
        if yolo_track_id not in self.yolo_to_sequential_id:
            new_id = self.get_next_available_track_id()
            self.yolo_to_sequential_id[yolo_track_id] = new_id
            self.active_tracks.add(yolo_track_id)
            print(f"Assigned new track ID {new_id} to YOLO track {yolo_track_id}")
        self.last_seen[yolo_track_id] = current_Time
        return self.yolo_to_sequential_id[yolo_track_id]

    def cleanup_stale_tracks(self):
        current_Time = time.time()
        stale_tracks = [
            track_id for track_id in self.active_tracks
            if current_Time - self.last_seen[track_id] > self.track_timeout
        ]
        for track_id in stale_tracks:
            self.active_tracks.remove(track_id)
            sequential_id = self.yolo_to_sequential_id.pop(track_id, None)
            if sequential_id:
                self.sequential_track_history.pop(sequential_id, None)
                self.track_history.pop(sequential_id, None)
            self.last_seen.pop(track_id, None)
            print(f"Cleaned up stale track ID {track_id}")

    def smooth_bbox(self, track_id, bbox, alpha=0.7):
        if track_id not in self.sequential_track_history:
            self.sequential_track_history[track_id] = [bbox]
            return bbox
        prev_bbox = self.sequential_track_history[track_id][-1]
        smoothed_bbox = [alpha * bbox[i] + (1 - alpha) * prev_bbox[i] for i in range(4)]
        self.sequential_track_history[track_id].append(smoothed_bbox)
        if len(self.sequential_track_history[track_id]) > self.max_history_length:
            self.sequential_track_history[track_id].pop(0)
        return smoothed_bbox