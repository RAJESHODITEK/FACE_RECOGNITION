# src/video_module/video_recorder.py
import cv2
import os
import threading
import logging
from datetime import datetime
from collections import defaultdict, deque
import time
import av
from queue import Queue, Empty
from pathlib import Path
from src.utility.config_manager import get_config

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class VideoRecorder:
    """
    Optimized video recorder with 5s pre-buffer + 5s post-buffer = 10s max videos in .ts format.
    Non-blocking async encoding with automatic cleanup of old frames.
    Includes automatic cleanup of old .ts and .img files.
    """

    def __init__(self, base_video_path=None, fps=None):
        config = get_config()
        self.logger = logging.getLogger(__name__)

        # Video path configuration
        if base_video_path is None:
            base_video_path = config.get('VIDEO_RECORDING', 'video_store_path', 'ZONE_VIDEOS')
        self.base_video_path = base_video_path
        os.makedirs(self.base_video_path, exist_ok=True)

        # FPS configuration
        self.fps = fps if fps else config.getint('VIDEO_RECORDING', 'fps', 10)

        # Buffer configuration: 5s pre + 5s post = 10s total
        self.pre_buffer_seconds = config.getint('VIDEO_RECORDING', 'pre_buffer_seconds', 10)
        self.post_buffer_seconds = config.getint('VIDEO_RECORDING', 'post_buffer_seconds', 5)
        self.total_video_duration = self.pre_buffer_seconds + self.post_buffer_seconds  # 10s

        self.pre_buffer_frames = self.pre_buffer_seconds * self.fps  # 50 frames
        self.post_buffer_frames = self.post_buffer_seconds * self.fps  # 50 frames
        self.max_frames = self.pre_buffer_frames + self.post_buffer_frames  # 100 frames total

        # Circular buffer size (keep 10 seconds of history for pre-buffer)
        self.buffer_seconds = 10  # Keep 10s of frames in memory
        self.buffer_size = self.buffer_seconds * self.fps  # 100 frames

        # Camera frame buffers (circular buffer with timestamp-based cleanup)
        self.camera_buffers = defaultdict(lambda: deque(maxlen=self.buffer_size))
        self.buffer_locks = defaultdict(threading.Lock)

        # Active recordings tracking
        self.active_recordings = {}
        self.encoding_queues = {}
        self.recordings_lock = threading.Lock()

        # Thread pool for video creation
        self.video_creation_threads = {}
        self.video_threads_lock = threading.Lock()

        # Frame rate limiting
        self.last_buffer_update = defaultdict(float)
        self.min_frame_interval = 1.0 / (self.fps * 1.2)  # Allow 20% faster updates

        # Codec settings for .ts format
        self.codec_preset = config.get('VIDEO_RECORDING', 'codec_preset', 'ultrafast')
        self.crf = config.getint('VIDEO_RECORDING', 'crf', 23)

        # Frame resize for efficiency
        self.max_width = config.getint('VIDEO_RECORDING', 'max_width', 1280)
        self.max_height = config.getint('VIDEO_RECORDING', 'max_height', 720)

        # Queue settings
        self.max_queue_size = self.post_buffer_frames + 20  # Only for live frames

        # Visualization settings
        self.bbox_color = (0, 255, 0)  # Green
        self.bbox_thickness = 2
        self.label_font_scale = 0.6
        self.label_thickness = 2

        # Frame cleanup settings
        self.frame_expiry_time = 10  # Delete frames older than 10 seconds
        self.frame_cleanup_interval = 2  # Run frame cleanup every 2 seconds

        # File cleanup settings
        self.file_expiry_time = 20  # Delete .ts and .img files older than 20 seconds
        self.file_cleanup_interval = 5  # Run file cleanup every 5 seconds

        # Start background cleanup threads
        self.cleanup_running = True

        # Frame cleanup thread
        self.frame_cleanup_thread = threading.Thread(
            target=self._frame_cleanup_loop,
            daemon=True,
            name="FrameCleanupThread"
        )
        self.frame_cleanup_thread.start()

        # File cleanup thread for .ts and .img files
        self.file_cleanup_thread = threading.Thread(
            target=self._file_cleanup_loop,
            daemon=True,
            name="FileCleanupThread"
        )
        self.file_cleanup_thread.start()

        self.logger.info(
            f"VideoRecorder initialized - Path: {self.base_video_path}, "
            f"FPS: {self.fps}, Pre-buffer: {self.pre_buffer_seconds}s, "
            f"Post-buffer: {self.post_buffer_seconds}s, Total: {self.total_video_duration}s"
        )
        self.logger.info(
            f"File cleanup enabled - .ts and .img files older than {self.file_expiry_time}s "
            f"will be deleted every {self.file_cleanup_interval}s"
        )

    def update_frame_buffer(self, camera_name, frame, tracked_objects=None):
        """
        Update circular buffer with latest frame (non-blocking, very fast).
        Frames older than 10 seconds are automatically removed by cleanup thread.
        """
        try:
            current_time = time.time()

            # Rate limiting - drop frames if coming too fast
            if current_time - self.last_buffer_update[camera_name] < self.min_frame_interval:
                return

            self.last_buffer_update[camera_name] = current_time

            # Resize if needed
            h, w = frame.shape[:2]
            if w > self.max_width or h > self.max_height:
                scale = min(self.max_width / w, self.max_height / h)
                new_w, new_h = int(w * scale), int(h * scale)
                frame = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_AREA)

            # Build bbox dictionary
            bbox_dict = {}
            if tracked_objects:
                for obj in tracked_objects:
                    bbox_dict[obj["track_id"]] = {
                        "box": obj["box"],
                        "cls": obj.get("cls", 0),
                        "type": obj.get("object_type", "Unknown"),
                        "subtype": obj.get("object_sub_type", "Unknown")
                    }

            # Add to circular buffer with timestamp
            with self.buffer_locks[camera_name]:
                self.camera_buffers[camera_name].append({
                    'frame': frame.copy(),
                    'timestamp': current_time,
                    'bbox_dict': bbox_dict
                })

        except Exception as e:
            self.logger.error(f"Error buffering frame for {camera_name}: {e}")

    def _frame_cleanup_loop(self):
        """
        Background thread that continuously removes frames older than 10 seconds.
        """
        while self.cleanup_running:
            try:
                time.sleep(self.frame_cleanup_interval)
                current_time = time.time()
                expiry_time = current_time - self.frame_expiry_time

                cameras_cleaned = 0
                frames_removed = 0

                # Clean old frames from each camera buffer
                for camera_name in list(self.camera_buffers.keys()):
                    with self.buffer_locks[camera_name]:
                        buffer = self.camera_buffers[camera_name]

                        if not buffer:
                            continue

                        # Count frames to remove
                        initial_len = len(buffer)

                        # Remove frames older than expiry_time from left side
                        while buffer and buffer[0]['timestamp'] < expiry_time:
                            buffer.popleft()
                            frames_removed += 1

                        if initial_len > len(buffer):
                            cameras_cleaned += 1

                # Clean up empty camera buffers
                cameras_to_remove = []
                for camera_name, last_update in self.last_buffer_update.items():
                    if current_time - last_update > 30:  # No update in 30 seconds
                        cameras_to_remove.append(camera_name)

                for camera_name in cameras_to_remove:
                    with self.buffer_locks[camera_name]:
                        if camera_name in self.camera_buffers:
                            del self.camera_buffers[camera_name]
                    if camera_name in self.last_buffer_update:
                        del self.last_buffer_update[camera_name]
                    if camera_name in self.buffer_locks:
                        del self.buffer_locks[camera_name]

                # Log cleanup stats periodically
                if frames_removed > 0 or cameras_to_remove:
                    self.logger.debug(
                        f"Frame Cleanup: Removed {frames_removed} old frames from {cameras_cleaned} cameras, "
                        f"Deleted {len(cameras_to_remove)} inactive camera buffers"
                    )

            except Exception as e:
                self.logger.error(f"Error in frame cleanup loop: {e}", exc_info=True)

    def _file_cleanup_loop(self):
        """
        Background thread that continuously deletes .ts and .img files older than 20 seconds.
        Runs in a loop checking the video storage directory.
        """
        self.logger.info(f"File cleanup thread started - checking {self.base_video_path}")

        while self.cleanup_running:
            try:
                time.sleep(self.file_cleanup_interval)
                current_time = time.time()
                expiry_time = current_time - self.file_expiry_time

                files_deleted = 0
                total_size_freed = 0

                # Walk through the video directory
                for root, dirs, files in os.walk(self.base_video_path):
                    for filename in files:
                        # Check if file is .ts or .img
                        if filename.endswith('.ts') or filename.endswith('.img'):
                            file_path = os.path.join(root, filename)

                            try:
                                # Get file modification time
                                file_mtime = os.path.getmtime(file_path)

                                # Delete if older than 20 seconds
                                if file_mtime < expiry_time:
                                    file_size = os.path.getsize(file_path)
                                    os.remove(file_path)
                                    files_deleted += 1
                                    total_size_freed += file_size

                                    self.logger.debug(
                                        f"Deleted old file: {filename} "
                                        f"(age: {current_time - file_mtime:.1f}s, "
                                        f"size: {file_size / 1024:.1f}KB)"
                                    )

                            except FileNotFoundError:
                                # File already deleted
                                pass
                            except Exception as e:
                                self.logger.error(f"Error deleting file {file_path}: {e}")

                # Log cleanup summary if files were deleted
                if files_deleted > 0:
                    self.logger.info(
                        f"File Cleanup: Deleted {files_deleted} old files "
                        f"(.ts/.img older than {self.file_expiry_time}s), "
                        f"freed {total_size_freed / (1024 * 1024):.2f}MB"
                    )

                # Clean up empty directories (optional)
                self._cleanup_empty_directories()

            except Exception as e:
                self.logger.error(f"Error in file cleanup loop: {e}", exc_info=True)

    def _cleanup_empty_directories(self):
        """
        Remove empty subdirectories in the video storage path.
        """
        try:
            for root, dirs, files in os.walk(self.base_video_path, topdown=False):
                for dir_name in dirs:
                    dir_path = os.path.join(root, dir_name)
                    try:
                        # Try to remove directory (will only work if empty)
                        if not os.listdir(dir_path):
                            os.rmdir(dir_path)
                            self.logger.debug(f"Removed empty directory: {dir_path}")
                    except OSError:
                        # Directory not empty or other error
                        pass
        except Exception as e:
            self.logger.error(f"Error cleaning empty directories: {e}")

    def start_recording(self, track_id, camera_name, frame_shape, object_type, object_sub_type):
        """
        Start recording for a track ID with 5s pre-buffer (non-blocking).
        Creates a dedicated thread for video encoding.
        Returns: relative video path for database storage
        """
        with self.recordings_lock:
            # If already recording, just update last seen time
            if track_id in self.active_recordings:
                self.active_recordings[track_id]['last_seen'] = time.time()
                return self.active_recordings[track_id]['relative_path']

        try:
            # Create directory structure: ZONE_VIDEOS/DD-MM-YYYY/camera_name/
            current_time = datetime.now()
            date_str = current_time.strftime('%d-%m-%Y')
            safe_camera = camera_name.replace(" ", "_").replace(":", "_").replace("/", "_").replace("\\", "_")

            dir_path = os.path.join(self.base_video_path, date_str, safe_camera)
            os.makedirs(dir_path, exist_ok=True)

            # Filename: trackID_timestamp.ts
            timestamp_str = current_time.strftime('%Y%m%d_%H%M%S_%f')
            filename = f"{track_id}_{timestamp_str}.ts"
            full_path = os.path.join(dir_path, filename)
            relative_path = os.path.join(date_str, safe_camera, filename)

            # Create encoding queue for post-buffer frames
            encoding_queue = Queue(maxsize=self.max_queue_size)

            # Get snapshot of buffered frames (last 5 seconds for pre-buffer)
            with self.buffer_locks[camera_name]:
                # Get all frames from buffer
                all_buffered = list(self.camera_buffers.get(camera_name, []))

            # Only take last 5 seconds (50 frames) for pre-buffer
            current_timestamp = time.time()
            pre_buffer_cutoff = current_timestamp - self.pre_buffer_seconds

            buffered_frames = [
                f for f in all_buffered
                if f['timestamp'] >= pre_buffer_cutoff
            ]

            # Store recording metadata
            with self.recordings_lock:
                self.active_recordings[track_id] = {
                    'camera_name': camera_name,
                    'last_seen': time.time(),
                    'start_time': time.time(),
                    'relative_path': relative_path,
                    'full_path': full_path,
                    'object_type': object_type,
                    'object_sub_type': object_sub_type,
                    'frame_shape': frame_shape,
                    'encoding_queue': encoding_queue,
                    'frames_written': 0,
                    'post_buffer_count': 0  # Track post-buffer frames
                }
                self.encoding_queues[track_id] = encoding_queue

            # Start dedicated video encoding thread for this track
            encoder_thread = threading.Thread(
                target=self._video_creation_worker,
                args=(track_id, buffered_frames, frame_shape, full_path, object_type, object_sub_type),
                daemon=True,
                name=f"VideoCreator_Track_{track_id}"
            )

            # Store thread reference
            with self.video_threads_lock:
                self.video_creation_threads[track_id] = encoder_thread

            encoder_thread.start()

            self.logger.info(
                f"Started recording - Track: {track_id}, Camera: {camera_name}, "
                f"Pre-buffer frames: {len(buffered_frames)}, Path: {relative_path}, "
                f"Thread: {encoder_thread.name}"
            )

            return relative_path

        except Exception as e:
            self.logger.error(f"Failed to start recording for track {track_id}: {e}", exc_info=True)
            return None

    def _video_creation_worker(self, track_id, buffered_frames, frame_shape, full_path, object_type, object_sub_type):
        """
        Dedicated thread worker for creating video for a single track ID.
        Handles both pre-buffer and post-buffer encoding.
        """
        self.logger.info(f"Video creation thread started for track {track_id}")

        container = None
        frames_written = 0

        try:
            # Open .ts container
            container = av.open(full_path, mode='w', format='mpegts')
            video_stream = container.add_stream('libx264', rate=self.fps)
            video_stream.width = frame_shape[1]
            video_stream.height = frame_shape[0]
            video_stream.pix_fmt = 'yuv420p'
            video_stream.options = {
                'preset': self.codec_preset,
                'tune': 'zerolatency',
                'crf': str(self.crf)
            }

            # PHASE 1: Encode pre-buffer frames (5 seconds before detection)
            for frame_data in buffered_frames[:self.pre_buffer_frames]:
                frame = frame_data['frame']
                bbox_dict = frame_data['bbox_dict']

                # Draw bbox if track exists in this frame
                if track_id in bbox_dict:
                    frame = self._draw_bbox(frame, track_id, bbox_dict[track_id])

                self._encode_frame(frame, video_stream, container)
                frames_written += 1

            self.logger.debug(f"Track {track_id}: Encoded {frames_written} pre-buffer frames")

            # PHASE 2: Encode post-buffer frames (5 seconds after detection)
            encoding_queue = self.encoding_queues[track_id]
            post_buffer_frames_written = 0

            while post_buffer_frames_written < self.post_buffer_frames:
                try:
                    # Get frame from queue (timeout 0.2s)
                    frame_data = encoding_queue.get(timeout=0.2)

                    # Stop signal received
                    if frame_data is None:
                        self.logger.info(
                            f"Track {track_id}: Stop signal received at {post_buffer_frames_written} post-buffer frames")
                        break

                    frame = frame_data['frame']
                    bbox_dict = frame_data['bbox_dict']

                    # Draw bbox if track exists
                    if track_id in bbox_dict:
                        frame = self._draw_bbox(frame, track_id, bbox_dict[track_id])

                    self._encode_frame(frame, video_stream, container)
                    frames_written += 1
                    post_buffer_frames_written += 1

                except Empty:
                    # No frame available, check if track is stale
                    with self.recordings_lock:
                        if track_id in self.active_recordings:
                            last_seen = self.active_recordings[track_id]['last_seen']
                            # If no update in 2 seconds, finalize video
                            if time.time() - last_seen > 2.0:
                                self.logger.info(
                                    f"Track {track_id}: No frames for 2s, finalizing with "
                                    f"{post_buffer_frames_written}/{self.post_buffer_frames} post-buffer frames"
                                )
                                break
                        else:
                            break
                    continue

            self.logger.debug(
                f"Track {track_id}: Encoded {post_buffer_frames_written} post-buffer frames, "
                f"Total: {frames_written} frames"
            )

            # Finalize video
            for packet in video_stream.encode(None):
                container.mux(packet)

            container.close()
            container = None

            # Calculate stats
            video_duration = frames_written / self.fps

            self.logger.info(
                f"Video saved - Track: {track_id}, Total frames: {frames_written}, "
                f"Duration: {video_duration:.1f}s, Path: {full_path}"
            )

        except Exception as e:
            self.logger.error(f"Video creation error for track {track_id}: {e}", exc_info=True)

        finally:
            # Cleanup
            if container:
                try:
                    container.close()
                except:
                    pass

            with self.recordings_lock:
                if track_id in self.active_recordings:
                    del self.active_recordings[track_id]
                if track_id in self.encoding_queues:
                    del self.encoding_queues[track_id]

            # Remove thread reference
            with self.video_threads_lock:
                if track_id in self.video_creation_threads:
                    del self.video_creation_threads[track_id]

            self.logger.info(f"Video creation thread finished for track {track_id}")

    def _draw_bbox(self, frame, track_id, bbox_info):
        """Draw bounding box and label on frame."""
        try:
            frame = frame.copy()
            x1, y1, x2, y2 = bbox_info["box"]

            # Draw rectangle
            cv2.rectangle(frame, (x1, y1), (x2, y2), self.bbox_color, self.bbox_thickness)

            # Create label
            obj_type = bbox_info.get("type", "Unknown")
            obj_subtype = bbox_info.get("subtype", "")

            label = f"{obj_type} ID:{track_id}"
            if obj_subtype and obj_subtype != "Unknown":
                label += f" {obj_subtype}"

            # Draw label background
            (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX,
                                          self.label_font_scale, self.label_thickness)
            cv2.rectangle(frame, (x1, y1 - th - 8), (x1 + tw + 4, y1), self.bbox_color, -1)

            # Draw label text
            cv2.putText(frame, label, (x1 + 2, y1 - 4),
                        cv2.FONT_HERSHEY_SIMPLEX, self.label_font_scale,
                        (0, 0, 0), self.label_thickness)

            return frame

        except Exception as e:
            self.logger.error(f"Error drawing bbox: {e}")
            return frame

    def _encode_frame(self, frame, video_stream, container):
        """Encode single frame to video stream."""
        try:
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            av_frame = av.VideoFrame.from_ndarray(frame_rgb, format='rgb24')

            for packet in video_stream.encode(av_frame):
                container.mux(packet)

        except Exception as e:
            self.logger.error(f"Frame encoding error: {e}")

    def write_frame(self, track_id, frame, tracked_objects):
        """
        Queue frame for encoding post-buffer (non-blocking, very fast).
        Stops automatically after 5 seconds (50 frames) of post-buffer.
        """
        if track_id not in self.encoding_queues:
            return

        try:
            # Check if we've reached post-buffer limit
            with self.recordings_lock:
                if track_id in self.active_recordings:
                    recording = self.active_recordings[track_id]

                    # Stop recording if post-buffer is full
                    if recording['post_buffer_count'] >= self.post_buffer_frames:
                        self.logger.debug(f"Track {track_id}: Post-buffer full, auto-stopping")
                        self.stop_recording(track_id)
                        return

            # Build bbox dict
            bbox_dict = {}
            for obj in tracked_objects:
                bbox_dict[obj["track_id"]] = {
                    "box": obj["box"],
                    "cls": obj.get("cls", 0),
                    "type": obj.get("object_type", "Unknown"),
                    "subtype": obj.get("object_sub_type", "Unknown")
                }

            # Try to put in queue (non-blocking)
            try:
                self.encoding_queues[track_id].put_nowait({
                    'frame': frame.copy(),
                    'bbox_dict': bbox_dict
                })

                # Update last seen time and post-buffer count
                with self.recordings_lock:
                    if track_id in self.active_recordings:
                        self.active_recordings[track_id]['last_seen'] = time.time()
                        self.active_recordings[track_id]['frames_written'] += 1
                        self.active_recordings[track_id]['post_buffer_count'] += 1

            except:
                # Queue full, skip frame (prevents blocking)
                pass

        except Exception as e:
            self.logger.error(f"Error queueing frame for track {track_id}: {e}")

    def stop_recording(self, track_id):
        """
        Send stop signal to encoder (non-blocking).
        """
        if track_id in self.encoding_queues:
            try:
                self.encoding_queues[track_id].put(None, timeout=0.5)
                self.logger.info(f"Stop signal sent for track {track_id}")
            except:
                pass

    def get_video_path(self, track_id):
        """Get relative video path for database storage."""
        with self.recordings_lock:
            if track_id in self.active_recordings:
                return self.active_recordings[track_id]['relative_path']
        return None

    def is_recording(self, track_id):
        """Check if track is currently being recorded."""
        with self.recordings_lock:
            return track_id in self.active_recordings

    def get_active_count(self):
        """Get number of active recordings."""
        with self.recordings_lock:
            return len(self.active_recordings)

    def get_active_threads_count(self):
        """Get number of active video creation threads."""
        with self.video_threads_lock:
            return len(self.video_creation_threads)

    def stop_all_recordings(self):
        """Stop all active recordings."""
        with self.recordings_lock:
            track_ids = list(self.active_recordings.keys())

        self.logger.info(f"Stopping all {len(track_ids)} recordings")

        for track_id in track_ids:
            self.stop_recording(track_id)

        # Wait for all video creation threads to finish (with timeout)
        with self.video_threads_lock:
            threads = list(self.video_creation_threads.values())

        for thread in threads:
            if thread.is_alive():
                thread.join(timeout=2)

        # Clear buffers
        self.camera_buffers.clear()
        self.last_buffer_update.clear()
        self.buffer_locks.clear()

    def shutdown(self):
        """Graceful shutdown."""
        self.logger.info("Shutting down VideoRecorder")
        self.cleanup_running = False
        self.stop_all_recordings()

        # Wait for cleanup threads
        if self.frame_cleanup_thread.is_alive():
            self.frame_cleanup_thread.join(timeout=2)

        if self.file_cleanup_thread.is_alive():
            self.file_cleanup_thread.join(timeout=2)

        self.logger.info("VideoRecorder shutdown complete")

    def __del__(self):
        """Cleanup on deletion."""
        self.shutdown()