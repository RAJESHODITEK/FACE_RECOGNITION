import cv2
import numpy as np
import time

class StreamModule:
    def __init__(self):
        self.buffer_size = 1

