import cv2
import numpy as np
import time
import threading
import queue
from gui.Core.audio import AudioThreadManager
from src.utility.shared_queue import shared_queue, original_frame_queues, current_camera_details, muted_ids_list


class ServiceModule:
    def __init__(self, camera_module, detection_module, observer_module, db_module, video_module):
        self.camera_module = camera_module
        self.detection_module = detection_module
        self.observer_module = observer_module
        self.db_module = db_module
        self.video_module = video_module
        self.obj_audio = AudioThreadManager()
        self.frame_stock_for_record_queue = queue.Queue(maxsize=20)
        # self.stock_image_processor_thread = threading.Thread(target=self.stock_image_processing, daemon=True)
        # self.stock_image_processor_thread.start()
        self.copy_frame = [None] * len(self.camera_module.rtsp_paths)
        self.frame_count = [0] * len(self.camera_module.rtsp_paths)
        self.skip_frames = 3
        self.frame_skip_counter = [0] * len(self.camera_module.rtsp_paths)
        self.detection_frame_count = [0] * len(self.camera_module.rtsp_paths)
        self.max_detection_age = 8
        self.last_valid_detections = [[] for _ in range(len(self.camera_module.rtsp_paths))]
        self.ids_inside_roi = [[] for _ in range(len(self.camera_module.rtsp_paths))]
        self.popup_shown = False
        self.stop_event = threading.Event()  # Shared stop event for all threads

    def process_video(self, display=True):
        frame_sizes = self.camera_module.get_frame_sizes_and_roi()
        capture_threads = []
        processing_threads = []
        num_cameras = len(self.camera_module.rtsp_paths)

        # Initialize combined frame display variables
        combined_frame = np.zeros((720 * 2, 1280 * 2, 3), dtype=np.uint8)
        last_valid_frames = [None] * num_cameras
        frame_timestamps = [0] * num_cameras
        max_frame_age = 0.5

        # Start capture threads for each camera
        for cam_idx in range(num_cameras):
            thread = threading.Thread(
                target=self.camera_module.capture_frames,
                args=(cam_idx, self.camera_module.rtsp_paths[cam_idx]),
                daemon=True
            )
            thread.start()
            capture_threads.append(thread)

        # Start processing threads for each camera
        for cam_idx in range(num_cameras):
            thread = threading.Thread(
                target=self.process_camera,
                args=(cam_idx, frame_sizes[cam_idx], display),
                daemon=True
            )
            thread.start()
            processing_threads.append(thread)

        print("Starting video processing for cameras...")
        try:
            while not self.camera_module.stop_event.is_set():
                # Handle keyboard input
                key = cv2.waitKey(1) & 0xFF
                if key == ord('q'):
                    self.camera_module.stop_event.set()
                    self.stop_event.set()
                    break
                elif key == ord('p'):
                    print("Pause/Resume not implemented in multi-threaded mode")

                # Integrated combined frame display logic
                all_success = True
                for cam_idx in range(num_cameras):
                    try:
                        ret, frame = original_frame_queues[cam_idx].get(timeout=0.1)
                        if ret and frame is not None:
                            resized_frame = cv2.resize(frame, (1280, 720))
                            last_valid_frames[cam_idx] = resized_frame
                            frame_timestamps[cam_idx] = time.time()
                        else:
                            all_success = False
                            # Use last valid frame if within max_frame_age
                            if (last_valid_frames[cam_idx] is not None and
                                    time.time() - frame_timestamps[cam_idx] < max_frame_age):
                                resized_frame = last_valid_frames[cam_idx]
                            else:
                                resized_frame = cv2.resize(self.camera_module.no_signal_img, (1280, 720))

                        # Place frame in combined_frame
                        combined_frame[
                        (cam_idx // 2) * 720:(cam_idx // 2 + 1) * 720,
                        (cam_idx % 2) * 1280:(cam_idx % 2 + 1) * 1280
                        ] = resized_frame

                    except queue.Empty:
                        all_success = False
                        # Fallback to last valid frame or no-signal image
                        if (last_valid_frames[cam_idx] is not None and
                                time.time() - frame_timestamps[cam_idx] < max_frame_age):
                            resized_frame = last_valid_frames[cam_idx]
                        else:
                            resized_frame = cv2.resize(self.camera_module.no_signal_img, (1280, 720))

                        combined_frame[
                        (cam_idx // 2) * 720:(cam_idx // 2 + 1) * 720,
                        (cam_idx % 2) * 1280:(cam_idx % 2 + 1) * 1280
                        ] = resized_frame

                # Put combined frame in shared queue
                try:
                    shared_queue.put(combined_frame.copy(), timeout=0.1)
                except queue.Full:
                    pass

                time.sleep(0.005)

        finally:
            # Cleanup
            self.camera_module.stop_event.set()
            self.stop_event.set()
            for thread in capture_threads + processing_threads:
                thread.join()
            cv2.destroyAllWindows()
            # self.video_module.cleanup_all_track_videos()
            total_time = time.time() - self.camera_module.start_time if hasattr(self.camera_module, 'start_time') else 0
            print(f"\nRTSP Stream Processing Complete!")
            print(f"Total Time: {total_time:.2f}s")
            print(f"Total frames processed: {self.frame_count}")
            print(
                f"Average FPS: {[self.frame_count[i] / total_time if total_time > 0 else 0 for i in range(len(self.camera_module.rtsp_paths))]}")

    def process_camera(self, cam_idx, frame_size, display):
        width, height = frame_size
        processing_times = []
        last_frame_time = time.time()
        start_time = time.time()

        while not self.stop_event.is_set():
            if self.camera_module.latest_frame_flags[cam_idx]:
                ret, frame = True, self.camera_module.latest_frames[cam_idx]
            else:
                ret, frame = False, None

            # Update ROI coordinates
            self.camera_module.roi_coords[cam_idx] = {
                'x1': int((current_camera_details.get("roi_start_width", 0) / 100) * width),
                'x2': int((current_camera_details.get("roi_end_width", 100) / 100) * width),
                'y1': int((current_camera_details.get("roi_start", 0) / 100) * height),
                'y2': int((current_camera_details.get("roi_end", 100) / 100) * height)
            }

            # Process frame
            annotated_frame = np.zeros((720, 1280, 3), dtype=np.uint8)
            if ret and frame is not None:
                clean_frame = frame.copy()
                self.copy_frame[cam_idx] = clean_frame
                annotated_frame = self._process_frame(clean_frame, self.frame_count[cam_idx], cam_idx)
                cv2.rectangle(
                    annotated_frame,
                    (self.camera_module.roi_coords[cam_idx]['x1'], self.camera_module.roi_coords[cam_idx]['y1']),
                    (self.camera_module.roi_coords[cam_idx]['x2'], self.camera_module.roi_coords[cam_idx]['y2']),
                    (0, 255, 0), 2
                )
                frame_info = f"{self.camera_module.Camera_Names[cam_idx]} | Frame: {self.frame_count[cam_idx]}"
                cv2.putText(annotated_frame, frame_info, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

                # FPS and latency
                frame_time = time.time() - last_frame_time
                processing_times.append(frame_time)
                if len(processing_times) > 20:
                    processing_times.pop(0)
                current_fps = 1.0 / frame_time if frame_time > 0 else 0
                avg_fps = len(processing_times) / sum(processing_times) if processing_times else 0
                fps_text = f"FPS: {current_fps:.1f} | Avg: {avg_fps:.1f}"
                cv2.putText(annotated_frame, fps_text, (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                latency = (time.time() - last_frame_time) * 1000
                latency_text = f"Latency: {latency:.1f}ms"
                cv2.putText(annotated_frame, latency_text, (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)

                # Status
                status_text = "Connected" if self.camera_module.connection_health[cam_idx][
                                                 'consecutive_failures'] == 0 else "Retrying..."
                status_color = (0, 255, 0) if self.camera_module.connection_health[cam_idx][
                                                  'consecutive_failures'] == 0 else (0, 165, 255)
                cv2.putText(annotated_frame, f"Status: {status_text}", (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                            status_color, 2)

                self.frame_count[cam_idx] += 1
            else:
                annotated_frame = cv2.resize(self.camera_module.no_signal_img, (1280, 720))

            # Put frame in queue for display
            try:
                original_frame_queues[cam_idx].put((ret, annotated_frame), timeout=0.01)
            except queue.Full:
                pass

            last_frame_time = time.time()

    def _process_frame(self, frame, frame_count, camera_id):
        self.frame_skip_counter[camera_id] += 1
        self.copy_frame[camera_id] = frame.copy()
        if frame is None or frame.size == 0 or frame.shape[0] == 0 or frame.shape[1] == 0:
            print(f"Camera {camera_id + 1}: Invalid frame detected, skipping")
            try:
                original_frame_queues[camera_id].put((False, None), timeout=0.01)
            except queue.Full:
                pass
            return frame
        should_process = (self.frame_skip_counter[camera_id] % (self.skip_frames + 1) == 0)
        if should_process:
            results = self.detection_module.detect_objects(frame, camera_id)
            self.observer_module.cleanup_stale_tracks()
            # if frame_count % 30 == 0:
            #     self.video_module.cleanup_buffers()
            if results[0].boxes is not None:
                self.update_last_valid_detections(results[0], frame_count, camera_id)
                self.detection_frame_count[camera_id] = frame_count
            should_record_frame = frame_count % 2 == 0
            if should_record_frame and results[0].boxes is not None:
                boxes = results[0].boxes.xyxy.cpu().numpy()
                confidences = results[0].boxes.conf.cpu().numpy()
                class_ids = results[0].boxes.cls.cpu().numpy().astype(int)
                track_ids = results[0].boxes.id.cpu().numpy().astype(int) if hasattr(results[0].boxes, 'id') and \
                                                                             results[0].boxes.id is not None else None
                for i, (box, conf, class_id) in enumerate(zip(boxes, confidences, class_ids)):
                    if conf < self.detection_module.conf_threshold or not self.detection_module.is_allowed_class(
                            class_id):
                        continue
                    yolo_track_id = track_ids[i] if track_ids is not None else i
                    sequential_track_id = self.observer_module.get_sequential_track_id(yolo_track_id)
                    if not self.frame_stock_for_record_queue.full():
                        self.frame_stock_for_record_queue.put(
                            (sequential_track_id, self.copy_frame[camera_id], boxes, confidences, class_ids, track_ids,
                             camera_id), block=False)
            annotated_frame = self.draw_tracks_with_persistence(frame, results if should_process else None, frame_count,
                                                                camera_id)
            try:
                original_frame_queues[camera_id].put((True, annotated_frame), timeout=0.01)
            except queue.Full:
                pass
            return annotated_frame
        else:
            annotated_frame = self.draw_tracks_with_persistence(frame, None, frame_count, camera_id)
            try:
                original_frame_queues[camera_id].put((True, annotated_frame), timeout=0.01)
            except queue.Full:
                pass
            return annotated_frame

    # def stock_image_processing(self):
    #     while True:
    #         if not self.frame_stock_for_record_queue.empty():
    #             params = self.frame_stock_for_record_queue.get()
    #             self.video_module.add_frame_to_track_video(params[0], params[2], params[1], params[6], params[3], params[4], params[5])
    #         time.sleep(0.05)

    def update_last_valid_detections(self, yolo_results, frame_count, camera_id):
        if yolo_results.boxes is None:
            return
        boxes = yolo_results.boxes.xyxy.cpu().numpy()
        confidences = yolo_results.boxes.conf.cpu().numpy()
        class_ids = yolo_results.boxes.cls.cpu().numpy().astype(int)
        track_ids = yolo_results.boxes.id.cpu().numpy().astype(int) if hasattr(yolo_results.boxes,
                                                                               'id') and yolo_results.boxes.id is not None else None
        self.last_valid_detections[camera_id] = []
        for i, (box, conf, class_id) in enumerate(zip(boxes, confidences, class_ids)):
            if conf < self.detection_module.conf_threshold or not self.detection_module.is_allowed_class(class_id):
                continue
            yolo_track_id = track_ids[i] if track_ids is not None else i
            sequential_track_id = self.observer_module.get_sequential_track_id(yolo_track_id)
            smoothed_box = self.observer_module.smooth_bbox(sequential_track_id, box.tolist())
            detection_data = {
                'box': smoothed_box,
                'confidence': conf,
                'class_id': class_id,
                'sequential_track_id': sequential_track_id,
                'yolo_track_id': yolo_track_id
            }
            self.last_valid_detections[camera_id].append(detection_data)

    def draw_tracks_with_persistence(self, frame, results, frame_count, camera_id):
        detection_age = frame_count - self.detection_frame_count[camera_id]
        use_last_detections = (results is None or results[0].boxes is None) and detection_age <= self.max_detection_age
        if use_last_detections and self.last_valid_detections[camera_id]:
            return self.draw_stored_detections(frame, camera_id)
        elif results is not None and results[0].boxes is not None:
            self.update_last_valid_detections(results[0], frame_count, camera_id)
            self.detection_frame_count[camera_id] = frame_count
            return self.draw_current_detections(frame, results[0], camera_id)
        else:
            return frame

    def draw_stored_detections(self, frame, camera_id):
        red_color = (0, 0, 255)
        red_dark = (0, 0, 180)
        self.ids_inside_roi[camera_id].clear()
        for detection in self.last_valid_detections[camera_id]:
            box = detection['box']
            conf = detection['confidence']
            class_id = detection['class_id']
            sequential_track_id = detection['sequential_track_id']
            x1, y1, x2, y2 = map(int, box)
            center_x = x1 + (x2 - x1) / 2
            center_y = y1 + (y2 - y1) / 2
            if (self.camera_module.roi_coords[camera_id]['x1'] < center_x < self.camera_module.roi_coords[camera_id][
                'x2'] and
                    self.camera_module.roi_coords[camera_id]['y1'] < center_y <
                    self.camera_module.roi_coords[camera_id]['y2']):
                generic_class_name = self.detection_module.get_generic_class_name(class_id)
                cv2.rectangle(frame, (x1, y1), (x2, y2), red_color, 2)
                label = f"ID:{sequential_track_id} {generic_class_name} {conf:.2f}"
                (label_width, label_height), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_DUPLEX, 0.6, 1)
                label_y = max(y1, label_height + 10)
                cv2.rectangle(frame, (x1, label_y - label_height - 10), (x1 + label_width + 10, label_y), red_dark, -1)
                cv2.putText(frame, label, (x1 + 5, label_y - 5), cv2.FONT_HERSHEY_DUPLEX, 0.6, (255, 255, 255), 1)
                self.ids_inside_roi[camera_id].append(sequential_track_id)
        for data in muted_ids_list[:]:
            if data["id"] not in self.ids_inside_roi[camera_id] and data["age"] < 30:
                data["age"] += 1
            elif data["id"] in self.ids_inside_roi[camera_id]:
                data["age"] = 2
            else:
                muted_ids_list.remove(data)
        for ids in self.ids_inside_roi[camera_id]:
            present = False
            for id in muted_ids_list:
                if ids == id["id"]:
                    present = True
            if not present and not self.popup_shown:
                self.popup_shown = True
                break
        return frame

    def draw_current_detections(self, frame, yolo_results, camera_id):
        boxes = yolo_results.boxes.xyxy.cpu().numpy()
        confidences = yolo_results.boxes.conf.cpu().numpy()
        class_ids = yolo_results.boxes.cls.cpu().numpy().astype(int)
        track_ids = yolo_results.boxes.id.cpu().numpy().astype(int) if hasattr(yolo_results.boxes,
                                                                               'id') and yolo_results.boxes.id is not None else None
        red_color = (0, 0, 255)
        red_dark = (0, 0, 180)
        clean_frame = frame.copy()  # Create a clean frame copy for cropping
        for i, (box, conf, class_id) in enumerate(zip(boxes, confidences, class_ids)):
            if conf < self.detection_module.conf_threshold or not self.detection_module.is_allowed_class(class_id):
                continue
            yolo_track_id = track_ids[i] if track_ids is not None else i
            sequential_track_id = self.observer_module.get_sequential_track_id(yolo_track_id)
            smoothed_box = self.observer_module.smooth_bbox(sequential_track_id, box.tolist())
            x1, y1, x2, y2 = map(int, smoothed_box)
            center_x = x1 + (x2 - x1) / 2
            center_y = y1 + (y2 - y1) / 2
            if (self.camera_module.roi_coords[camera_id]['x1'] < center_x < self.camera_module.roi_coords[camera_id][
                'x2'] and
                    self.camera_module.roi_coords[camera_id]['y1'] < center_y <
                    self.camera_module.roi_coords[camera_id]['y2']):
                self.video_module.save_cropped_object(clean_frame, sequential_track_id, class_id, box, conf, camera_id,
                                                      self.camera_module.Camera_Names)
                generic_class_name = self.detection_module.get_generic_class_name(class_id)
                cv2.rectangle(frame, (x1, y1), (x2, y2), red_color, 2)
                label = f"ID:{sequential_track_id} {generic_class_name} {conf:.2f}"
                (label_width, label_height), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_DUPLEX, 0.6, 1)
                label_y = max(y1, label_height + 10)
                cv2.rectangle(frame, (x1, label_y - label_height - 10), (x1 + label_width + 10, label_y), red_dark, -1)
                cv2.putText(frame, label, (x1 + 5, label_y - 5), cv2.FONT_HERSHEY_DUPLEX, 0.6, (255, 255, 255), 1)
        return frame