import cv2
import zmq
import base64
import numpy as np

def main():
    context = zmq.Context()
    socket = context.socket(zmq.SUB)

    # Connect to server (replace IP if running on another machine)
    socket.connect("tcp://127.0.0.1:5555")

    # Subscribe to specific camera(s)
    socket.setsockopt_string(zmq.SUBSCRIBE, "Camera1")
    socket.setsockopt_string(zmq.SUBSCRIBE, "Camera2")

    while True:
        message = socket.recv_string()
        cam_id, jpg_as_text = message.split(" ", 1)
        jpg_original = base64.b64decode(jpg_as_text)
        np_arr = np.frombuffer(jpg_original, dtype=np.uint8)
        frame = cv2.imdecode(np_arr, 1)

        cv2.imshow(cam_id, frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
