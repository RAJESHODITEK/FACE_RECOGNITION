import cv2
import threading
import av
import time
from flask import Flask, Response, render_template_string


class RTSPCamera:
    """Simple RTSP camera reader using OpenCV."""
    def __init__(self, rtsp_url):
        self.rtsp_url = rtsp_url
        self.cap = cv2.VideoCapture(rtsp_url)
        if not self.cap.isOpened():
            print(f"[ERROR] Cannot open RTSP stream: {rtsp_url}")
        self.lock = threading.Lock()
        self.frame = None
        self.running = True

        # Start background reader thread
        self.thread = threading.Thread(target=self._update, daemon=True)
        self.thread.start()

    def _update(self):
        while self.running:
            ret, frame = self.cap.read()
            if not ret:
                # Try reconnect after 1s
                time.sleep(1)
                self.cap.release()
                self.cap = cv2.VideoCapture(self.rtsp_url)
                continue
            with self.lock:
                self.frame = frame
            time.sleep(0.01)

    def get_frame(self):
        with self.lock:
            return None if self.frame is None else self.frame.copy()

    def release(self):
        self.running = False
        self.cap.release()


class MultiCameraStreamer:
    def __init__(self, cameras: dict, host='0.0.0.0', port=5000):
        """
        cameras: dict { "cam1": "rtsp://...", "cam2": "rtsp://..." }
        """
        self.app = Flask(__name__)
        self.host = host
        self.port = port

        # Init RTSP cameras
        self.cameras = {str(cid): RTSPCamera(url) for cid, url in cameras.items()}


        self._setup_routes()

    def _generate_frames(self, cam_id):
        cam = self.cameras[cam_id]
        while True:
            frame = cam.get_frame()
            if frame is None:
                continue
            _, buf = cv2.imencode('.jpg', frame)
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + buf.tobytes() + b'\r\n')

    def _setup_routes(self):
        @self.app.route('/')
        def index():
            cams = list(self.cameras.keys())
            return render_template_string('''
                <html>
                  <head><title>Multi-Camera Stream</title></head>
                  <body style="background:#222;color:#fff;font-family:sans-serif">
                    <h1>📡 Multi-Camera RTSP Streams</h1>
                    {% for cam in cams %}
                      <div style="margin-bottom:30px;">
                        <h2>{{cam}}</h2>
                        <img src="/live/{{cam}}" width="640"
                             style="border:4px solid #007BFF;border-radius:10px;">
                      </div>
                    {% endfor %}
                  </body>
                </html>
            ''', cams=cams)

        @self.app.route('/live/<cam_id>')
        def video_feed(cam_id):
            if cam_id not in self.cameras:
                return f"Camera '{cam_id}' not found.", 404
            return Response(
                self._generate_frames(cam_id),
                mimetype='multipart/x-mixed-replace; boundary=frame'
            )

    def start(self):
        # Start Flask server in thread
        flask_thr = threading.Thread(
            target=self.app.run,
            kwargs={'host': self.host, 'port': self.port, 'debug': False, 'use_reloader': False},
            daemon=True
        )
        flask_thr.start()
        print(f"[INFO] Flask server running on http://{self.host}:{self.port}")
        return flask_thr

    def stop(self):
        for cam in self.cameras.values():
            cam.release()


if __name__ == "__main__":
    # Example usage
    cam_dict = {
        "Camera1": "rtsp://admin:Admin@123@10.30.30.49/1",
        "Camera2": "rtsp://admin:Oditek123@@10.30.30.53/1"
    }
    streamer = MultiCameraStreamer(cam_dict, port=5000)
    streamer.start()

    while True:
        time.sleep(1)
