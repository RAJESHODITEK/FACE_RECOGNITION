# src/storage_module/frame_data_storage.py
import os
import cv2
import threading
import queue
import logging
from datetime import datetime
from pathlib import Path


class FrameDataStorage:
    """
    Stores raw frames and detection data for later processing using TOON format.
    TOON (Token-Oriented Object Notation) minimizes token usage for LLM processing.
    Creates folder structure: base_path/camera_name/YYYY-MM-DD/frame_timestamp.jpg + .toon
    All detections for a frame are stored in one TOON file.
    """

    def __init__(self, base_path="frame_data_storage", max_queue_size=1000):
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)

        self.logger = logging.getLogger(__name__)
        self.storage_queue = queue.Queue(maxsize=max_queue_size)

        # Storage thread
        self.storage_thread = None
        self.is_running = False

        # Statistics
        self.frames_saved = 0
        self.frames_failed = 0

    def start(self):
        """Start the storage thread"""
        if not self.is_running:
            self.is_running = True
            self.storage_thread = threading.Thread(target=self._storage_worker, daemon=True)
            self.storage_thread.start()
            self.logger.info("Frame data storage thread started (using TOON format)")

    def stop(self):
        """Stop the storage thread gracefully"""
        self.is_running = False
        if self.storage_thread:
            self.storage_thread.join(timeout=5)
        self.logger.info(f"Frame data storage stopped. Saved: {self.frames_saved}, Failed: {self.frames_failed}")

    def save_frame_data(self, frame, tracked_objects, camera_name, timestamp=None):
        """
        Queue frame and detection data for storage.

        Args:
            frame: numpy array (BGR image)
            tracked_objects: list of detection dictionaries
            camera_name: string
            timestamp: datetime object (defaults to now)
        """
        if timestamp is None:
            timestamp = datetime.now()

        try:
            # Put data in queue without blocking
            self.storage_queue.put_nowait({
                'frame': frame.copy(),  # Copy to avoid modification
                'tracked_objects': tracked_objects,
                'camera_name': camera_name,
                'timestamp': timestamp
            })
        except queue.Full:
            self.logger.warning(f"Storage queue full, dropping frame from {camera_name}")

    def _storage_worker(self):
        """Background thread that saves frames and TOON data"""
        while self.is_running:
            try:
                # Get data from queue with timeout
                data = self.storage_queue.get(timeout=0.5)
                self._save_frame_and_toon(
                    data['frame'],
                    data['tracked_objects'],
                    data['camera_name'],
                    data['timestamp']
                )
                self.storage_queue.task_done()

            except queue.Empty:
                continue
            except Exception as e:
                self.logger.error(f"Error in storage worker: {e}", exc_info=True)
                self.frames_failed += 1

    def _save_frame_and_toon(self, frame, tracked_objects, camera_name, timestamp):
        """Save frame image and detection data in TOON format (Token-Oriented Object Notation)"""
        try:
            # Create folder structure: camera_name/YYYY-MM-DD/
            date_str = timestamp.strftime("%Y-%m-%d")

            folder_path = self.base_path / camera_name / date_str
            folder_path.mkdir(parents=True, exist_ok=True)

            # Generate filename: timestamp_microseconds
            filename_base = timestamp.strftime("%Y%m%d_%H%M%S_%f")

            # Save image
            image_path = folder_path / f"{filename_base}.jpg"
            cv2.imwrite(str(image_path), frame, [cv2.IMWRITE_JPEG_QUALITY, 95])

            # Prepare TOON format data
            # TOON uses compact, token-efficient notation
            toon_path = folder_path / f"{filename_base}.toon"

            with open(toon_path, 'w') as f:
                # Frame metadata (compact single line)
                h, w = frame.shape[:2]
                f.write(
                    f"@f:{camera_name}|{timestamp.isoformat()}|{filename_base}.jpg|{w}x{h}|n:{len(tracked_objects)}\n")

                # Detection header (shortened field names for token efficiency)
                # tid=track_id, b=bbox, c=class_id, t=object_type, st=sub_type, z=zone
                f.write("@d:tid|b|c|t|st|z\n")

                # Write each detection in compact format
                for obj in tracked_objects:
                    tid = obj.get('track_id', -1)
                    box = obj.get('box', [0, 0, 0, 0])
                    # Compact bbox notation: x1,y1,x2,y2
                    bbox_str = f"{box[0]},{box[1]},{box[2]},{box[3]}"
                    cid = obj.get('cls', -1)
                    otype = obj.get('object_type', 'Unk')
                    osub = obj.get('object_sub_type', 'Unk')
                    zone = obj.get('zone_name', 'Unk')

                    # Abbreviated values for common types to save tokens
                    otype = self._abbreviate_type(otype)
                    osub = self._abbreviate_subtype(osub)
                    zone = self._abbreviate_zone(zone)

                    # Single line per detection, pipe-separated
                    f.write(f"{tid}|{bbox_str}|{cid}|{otype}|{osub}|{zone}\n")

            self.frames_saved += 1

            if self.frames_saved % 100 == 0:
                self.logger.info(f"Frame data storage: {self.frames_saved} frames saved (TOON format)")

        except Exception as e:
            self.logger.error(f"Failed to save frame data: {e}", exc_info=True)
            self.frames_failed += 1

    def _abbreviate_type(self, obj_type):
        """Abbreviate object type to save tokens"""
        abbrev = {
            'Person': 'P',
            'Vehicle': 'V',
            'Animal': 'A',
            'Others': 'O',
            'Unknown': 'U'
        }
        return abbrev.get(obj_type, obj_type[:3])

    def _abbreviate_subtype(self, sub_type):
        """Abbreviate sub type to save tokens"""
        abbrev = {
            'Male': 'M',
            'Female': 'F',
            'Unknown': 'U',
            'Car': 'C',
            'Truck': 'T',
            'Bus': 'B',
            'Motorcycle': 'MC',
            'Bicycle': 'BC'
        }
        return abbrev.get(sub_type, sub_type[:3] if len(sub_type) > 3 else sub_type)

    def _abbreviate_zone(self, zone_name):
        """Abbreviate zone name to save tokens"""
        if zone_name == 'Unknown' or zone_name == 'Outside Zones':
            return 'Out'
        # Keep first 10 chars for custom zones
        return zone_name[:10] if len(zone_name) > 10 else zone_name

    def get_stats(self):
        """Return storage statistics"""
        return {
            'frames_saved': self.frames_saved,
            'frames_failed': self.frames_failed,
            'queue_size': self.storage_queue.qsize()
        }