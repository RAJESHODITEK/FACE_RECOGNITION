# src/tracking_module/tracking_manager.py
# CRITICAL FIX: Added proper video recording stop logic
# NEW: Added frame data storage for raw frames and detection data

import time
import cv2
import numpy as np
import base64
from datetime import datetime
from collections import defaultdict
import logging
from src.camera_module.camera_manager import CameraManager
from src.tracking_module.frame_data_storage import FrameDataStorage
from src.tracking_module.sort import Sort
from src.utility.coco_classes import coco_classes

from ultralytics import YOLO
import torch
from src.utility.config_manager import get_config
import threading
from src.utility.point_in_polygon import point_in_polygon

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class TrackingManager:
    def __init__(self, camera_manager: CameraManager, db_module=None, camera_names=None,
                 camera_frame_queue=None, roi_dict=None, video_recorder=None):
        config = get_config()
        self.logger = logging.getLogger(__name__)

        self.objcamera_manager = camera_manager
        self.tracking_queue = self.objcamera_manager.tracking_queue
        self.db_module = db_module
        self.camera_names = camera_names or {}
        self.camera_frame_queue = camera_frame_queue

        # Video recorder
        self.video_recorder = video_recorder

        # NEW: Frame data storage for raw frames and detection data
        self.enable_frame_storage = config.getint('STORAGE', 'enable_frame_storage', 0) > 0
        self.frame_storage = None
        if self.enable_frame_storage:
            storage_path = config.get('STORAGE', 'frame_storage_path', 'frame_data_storage')
            max_queue_size = config.getint('STORAGE', 'max_storage_queue_size', 1000)
            self.frame_storage = FrameDataStorage(base_path=storage_path, max_queue_size=max_queue_size)
            self.frame_storage.start()
            self.logger.info(f"[{self.camera_names.get(camera_manager.cam_idx, 'Unknown')}] Frame data storage enabled at {storage_path}")

        # Tracking data
        self.tracked_objects_first_seen = {}
        self.tracked_objects_frame_count = {}
        self.trackers = {}
        self.track_maps = defaultdict(dict)

        # Gender tracking
        self.tracked_genders = {}

        # Camera info
        self.frame_count = 0
        self.camera_name = self.camera_names.get(camera_manager.cam_idx, f"Camera_{camera_manager.cam_idx}")
        self.roi_dict = roi_dict or {}

        # ROI animation variables
        self.roi_animation_time = time.time()
        self.roi_cache = None

        # Multi-zone support
        self.camera_zones = []
        self.pixel_zones = []
        self.zones_lock = threading.Lock()
        self.camera_id = None

        # Load zones from database
        if self.db_module:
            self.camera_id = self.db_module.get_camera_id_by_name(self.camera_name)
            if self.camera_id:
                self.camera_zones = self.db_module.get_all_zones_for_camera(self.camera_id)

        # Gender model - lazy loading
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.gender_model = None
        self.gender_lock = threading.Lock()

        # Get gender detection settings from config
        self.gender_model_path = config.get('GENDER', 'model_path', 'gender.pt')
        self.gender_confidence_threshold = config.getfloat('GENDER', 'confidence_threshold', 0.5)
        self.gender_image_size = config.getint('GENDER', 'image_size', 160)
        self.min_brightness = config.getint('GENDER', 'min_brightness', 35)
        self.max_brightness = config.getint('GENDER', 'max_brightness', 215)

        # Storage settings from config
        self.min_frames_for_storage = config.getint('TRACKER', 'min_frames_for_storage', 3)

        # Full frame encoding settings from config
        self.jpeg_quality = config.getint('VIEW', 'image_quality_for_event', 85)
        self.max_frame_width = config.getint('VIEW', 'max_image_width', 1280)
        self.max_frame_height = config.getint('VIEW', 'max_image_height', 720)

        # FPS tracking
        self.fps_counter = 0
        self.fps_start_time = time.time()
        self.fps_log_interval = config.getint('DETECTION', 'fps_log_interval', 30)

        # Visualization settings from config
        self.enable_visualization = config.getint('VIEW', 'value', 1) > 0
        self.bbox_thickness = config.getint('VIEW', 'bbox_thickness', 2)
        self.label_font_scale = config.getfloat('VIEW', 'label_font_scale', 0.6)

        # Sleep settings from config
        self.tracking_sleep = config.getfloat('VIEW', 'tracking_sleep', 0.01)
        self.roi_cache_update_interval = config.getint('ROI', 'cache_update_interval', 100)

        # Video recording tracking - CRITICAL FIX
        self.active_video_tracks = {}
        self.tracks_last_seen = {}  # Track when each object was last seen

    def _load_gender_model(self):
        """Lazy load gender model only when needed"""
        if self.gender_model is None:
            with self.gender_lock:
                if self.gender_model is None:
                    try:
                        self.gender_model = YOLO(self.gender_model_path)
                        if self.device == 'cuda':
                            self.gender_model.half()
                        self.logger.info(f"[{self.camera_name}] Gender model loaded")
                    except Exception as e:
                        self.logger.error(f"[{self.camera_name}] Failed to load gender model: {e}")
                        self.gender_model = None

    def _encode_full_frame_with_single_bbox(self, frame, target_object):
        """Encode full frame with ONLY ONE specific object's bounding box drawn"""
        try:
            annotated_frame = frame.copy()
            x1, y1, x2, y2 = target_object["box"]
            track_id = target_object["track_id"]
            cls = target_object["cls"]

            object_type, object_sub_type = self.map_class_to_category(cls, track_id)

            color = (0, 0, 255)
            border_color = (0, 0, 255)
            cv2.rectangle(annotated_frame, (x1, y1), (x2, y2), border_color, 3, lineType=cv2.LINE_AA)
            cv2.rectangle(annotated_frame, (x1, y1), (x2, y2), color, self.bbox_thickness, lineType=cv2.LINE_AA)

            label = f"{object_type} ID {track_id} {object_sub_type}"

            (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, self.label_font_scale, 2)
            cv2.rectangle(annotated_frame, (x1, y1 - th - 12), (x1 + tw + 8, y1), color, -1)
            cv2.putText(annotated_frame, label, (x1 + 4, y1 - 6),
                        cv2.FONT_HERSHEY_SIMPLEX, self.label_font_scale, (0, 0, 0), 2, lineType=cv2.LINE_AA)

            h, w = annotated_frame.shape[:2]
            if w > self.max_frame_width or h > self.max_frame_height:
                scale = min(self.max_frame_width / w, self.max_frame_height / h)
                new_w, new_h = int(w * scale), int(h * scale)
                annotated_frame = cv2.resize(annotated_frame, (new_w, new_h), interpolation=cv2.INTER_AREA)

            encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), self.jpeg_quality]
            _, buffer = cv2.imencode('.jpg', annotated_frame, encode_param)
            encoded = base64.b64encode(buffer).decode('utf-8')

            return encoded

        except Exception as e:
            self.logger.error(f"[{self.camera_name}] Error encoding full frame: {e}", exc_info=True)
            return None

    def _frame_quality_check(self, region):
        """Fast quality check for cropped regions"""
        try:
            # Check minimum size
            if region.size == 0 or region.shape[0] < 40 or region.shape[1] < 40:
                self.logger.debug(f"[{self.camera_name}] Quality check failed - Region too small: {region.shape}")
                return False

            # Check brightness
            gray = cv2.cvtColor(region[::2, ::2], cv2.COLOR_BGR2GRAY)
            brightness = np.mean(gray)

            is_valid = self.min_brightness < brightness < self.max_brightness

            if not is_valid:
                self.logger.debug(
                    f"[{self.camera_name}] Quality check failed - Brightness {brightness:.1f} outside range [{self.min_brightness}, {self.max_brightness}]")
            else:
                self.logger.debug(f"[{self.camera_name}] Quality check passed - Brightness: {brightness:.1f}")

            return is_valid
        except Exception as e:
            self.logger.debug(f"[{self.camera_name}] Frame quality check error: {e}")
            return False

    def get_gender_yolo(self, img_bgr):
        """Gender detection with proper logging"""
        try:
            self._load_gender_model()
            if self.gender_model is None:
                self.logger.warning(f"[{self.camera_name}] Gender model not available")
                return "Unknown"

            # Convert BGR to RGB
            img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)

            with torch.no_grad():
                results = self.gender_model.predict(
                    img_rgb,
                    conf=self.gender_confidence_threshold,
                    imgsz=self.gender_image_size,
                    verbose=False,
                    device=self.device,
                    half=True if self.device == 'cuda' else False
                )

            if not results or len(results[0].boxes) == 0:
                self.logger.debug(f"[{self.camera_name}] Gender detection - No results")
                return "Unknown"

            boxes = results[0].boxes
            best_box = max(boxes, key=lambda b: float(b.conf[0].item()))

            cls = int(best_box.cls[0].item())
            confidence = float(best_box.conf[0].item())

            self.logger.debug(f"[{self.camera_name}] Gender detection - Class: {cls}, Confidence: {confidence:.2f}")

            if confidence < self.gender_confidence_threshold:
                self.logger.debug(
                    f"[{self.camera_name}] Gender confidence too low: {confidence:.2f} < {self.gender_confidence_threshold}")
                return "Unknown"

            # Map class to gender (class 0 = Female, class 1 = Male)
            gender = "Male" if cls == 1 else ("Female" if cls == 0 else "Unknown")

            self.logger.debug(f"[{self.camera_name}] Gender detected: {gender} (confidence: {confidence:.2f})")

            return gender

        except Exception as e:
            self.logger.error(f"[{self.camera_name}] Error in gender detection: {e}", exc_info=True)
            return "Unknown"

    def _update_pixel_zones(self, frame_shape):
        """Convert percentage zone coordinates to pixel coordinates"""
        if self.pixel_zones and self.frame_count % self.roi_cache_update_interval != 0:
            return self.pixel_zones

        with self.zones_lock:
            h, w = frame_shape[:2]
            self.pixel_zones = []

            for zone in self.camera_zones:
                points = zone['points']
                if len(points) >= 3:
                    pixel_points = [
                        (int(point['x'] * w / 100), int(point['y'] * h / 100))
                        for point in points
                    ]
                    self.pixel_zones.append({
                        'name': zone['name'],
                        'points': pixel_points
                    })

        return self.pixel_zones

    def _get_zone_name_for_detection(self, box, frame_shape):
        """Determine which zone a detection belongs to"""
        x1, y1, x2, y2 = box
        center_x = (x1 + x2) / 2
        center_y = (y1 + y2) / 2

        pixel_zones = self._update_pixel_zones(frame_shape)

        for zone in pixel_zones:
            if point_in_polygon(center_x, center_y, zone['points']):
                return zone['name']

        return "Outside Zones"

    def _draw_simple_roi(self, frame):
        """Draw ALL zones with different colors and names"""
        pixel_zones = self._update_pixel_zones(frame.shape)

        if not pixel_zones:
            return frame

        try:
            zone_colors = [
                (0, 255, 0),  # Green
                (255, 0, 0),  # Blue
                (0, 255, 255),  # Yellow
                (255, 0, 255),  # Magenta
                (0, 165, 255),  # Orange
            ]

            for idx, zone in enumerate(pixel_zones):
                points = zone['points']
                zone_name = zone['name']

                if len(points) < 3:
                    continue

                color = zone_colors[idx % len(zone_colors)]

                points_array = np.array(points, dtype=np.int32).reshape((-1, 1, 2))
                cv2.polylines(frame, [points_array], isClosed=True,
                              color=color, thickness=self.bbox_thickness, lineType=cv2.LINE_AA)

                min_x, min_y = np.min(points, axis=0)

                (tw, th), _ = cv2.getTextSize(zone_name, cv2.FONT_HERSHEY_SIMPLEX,
                                              self.label_font_scale, 2)
                cv2.rectangle(frame,
                              (int(min_x) + 5, int(min_y) + 10),
                              (int(min_x) + tw + 15, int(min_y) + th + 20),
                              color, -1)

                cv2.putText(frame, zone_name,
                            (int(min_x) + 10, int(min_y) + 25 + th),
                            cv2.FONT_HERSHEY_SIMPLEX, self.label_font_scale,
                            (0, 0, 0), 2, cv2.LINE_AA)

            return frame

        except Exception as e:
            self.logger.warning(f"[{self.camera_name}] Error drawing zones: {e}")
            return frame

    def _draw_visualization(self, frame, tracked_objects):
        """Full visualization"""
        for obj in tracked_objects:
            x1, y1, x2, y2 = obj["box"]
            track_id = obj["track_id"]
            cls = obj["cls"]

            color = (0, 255, 0)
            border_color = (255, 255, 255)
            cv2.rectangle(frame, (x1, y1), (x2, y2), border_color, self.bbox_thickness, lineType=cv2.LINE_AA)
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, self.bbox_thickness, lineType=cv2.LINE_AA)

            object_type, object_sub_type = self.map_class_to_category(cls, track_id)
            label = f"{object_type} ID {track_id} {object_sub_type}"

            (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, self.label_font_scale, 2)
            cv2.rectangle(frame, (x1, y1 - th - 10), (x1 + tw + 6, y1), color, -1)
            cv2.putText(frame, label, (x1 + 3, y1 - 5),
                        cv2.FONT_HERSHEY_SIMPLEX, self.label_font_scale, (0, 0, 0), 2, lineType=cv2.LINE_AA)

        return frame

    def map_class_to_category(self, cls_id, track_id=None):
        """Map class to category"""
        if cls_id == 0:
            if track_id is not None and track_id in self.tracked_genders:
                gender = self.tracked_genders[track_id]
                return "Person", gender
            return "Person", "Unknown"
        elif cls_id in {1, 2, 3, 5, 7}:
            vehicle_name = coco_classes.get(cls_id, "Unknown")
            return "Vehicle", vehicle_name.capitalize()
        elif 14 <= cls_id <= 20:
            animal_name = coco_classes.get(cls_id, "Unknown")
            return "Animal", animal_name.capitalize()
        else:
            unknown_name = coco_classes.get(cls_id, "Unknown")
            return "Others", unknown_name.capitalize()

    def track(self):
        """Tracking loop with multi-zone video recording - CRITICAL FIX FOR VIDEO STOPPING"""
        config = get_config()
        max_age = config.getint('TRACKER', 'max_age', 30)
        min_hits = config.getint('TRACKER', 'min_hits', 2)
        iou_threshold = config.getfloat('TRACKER', 'iou_threshold', 0.25)

        while True:
            try:
                if self.objcamera_manager.detection_queue.empty():
                    time.sleep(0.02)
                    continue

                data = self.objcamera_manager.detection_queue.get(timeout=0.1)
                frame = data["frame"]
                detections = data["detections"]
                self.frame_count += 1
                current_time = time.time()

                # Update frame buffer for video recording
                if self.video_recorder:
                    tracked_objs_for_buffer = []
                    for det in detections:
                        tracked_objs_for_buffer.append({
                            "track_id": -1,
                            "box": det["box"],
                            "cls": det["cls"]
                        })
                    self.video_recorder.update_frame_buffer(
                        self.camera_name,
                        frame,
                        tracked_objs_for_buffer
                    )

                grouped_dets = defaultdict(list)
                for det in detections:
                    cls = det["cls"]
                    grouped_dets[cls].append([*det["box"], det["conf"]])

                tracked_objects = []
                current_track_ids = set()

                for cls, dets_list in grouped_dets.items():
                    dets_np = np.array(dets_list) if dets_list else np.empty((0, 5))

                    if cls not in self.trackers:
                        self.trackers[cls] = Sort(max_age=max_age, min_hits=min_hits, iou_threshold=iou_threshold)

                    tracks = self.trackers[cls].update(dets_np)

                    for track in tracks:
                        x1, y1, x2, y2, local_id = map(int, track)

                        if local_id not in self.track_maps[cls]:
                            self.track_maps[cls][local_id] = self.db_module.last_track_id + local_id
                            self.tracked_objects_frame_count[self.track_maps[cls][local_id]] = 0

                        global_id = self.track_maps[cls][local_id]
                        current_track_ids.add(global_id)
                        self.tracked_objects_frame_count[global_id] += 1

                        # CRITICAL FIX: Update last seen time
                        self.tracks_last_seen[global_id] = current_time

                        # Gender detection for persons only
                        if cls == 0 and global_id not in self.tracked_genders:
                            person_crop = frame[y1:y2, x1:x2]
                            if self._frame_quality_check(person_crop):
                                detected_gender = self.get_gender_yolo(person_crop)
                                if detected_gender != "Unknown":
                                    self.tracked_genders[global_id] = detected_gender
                                    self.logger.info(
                                        f"[{self.camera_name}] Track {global_id} - Gender detected: {detected_gender}")
                                else:
                                    self.logger.debug(f"[{self.camera_name}] Track {global_id} - Gender unknown")
                            else:
                                self.logger.debug(
                                    f"[{self.camera_name}] Track {global_id} - Frame quality check failed for gender detection")

                        object_type, object_sub_type = self.map_class_to_category(cls, global_id)
                        zone_name = self._get_zone_name_for_detection([x1, y1, x2, y2], frame.shape)

                        tracked_obj = {
                            "track_id": global_id,
                            "box": [x1, y1, x2, y2],
                            "cls": cls,
                            "object_type": object_type,
                            "object_sub_type": object_sub_type,
                            "zone_name": zone_name
                        }
                        tracked_objects.append(tracked_obj)

                        # Video recording logic
                        # if self.video_recorder:
                        #     if global_id not in self.active_video_tracks:
                        #         if self.tracked_objects_frame_count[global_id] >= self.min_frames_for_storage:
                        #             video_path = self.video_recorder.start_recording(
                        #                 track_id=global_id,
                        #                 camera_name=self.camera_name,
                        #                 frame_shape=frame.shape,
                        #                 object_type=object_type,
                        #                 object_sub_type=object_sub_type
                        #             )
                        #             if video_path:
                        #                 self.active_video_tracks[global_id] = video_path
                        #                 self.logger.info(
                        #                     f"[{self.camera_name}] Started recording for track {global_id}")
                        #
                        #     if global_id in self.active_video_tracks:
                        #         self.video_recorder.write_frame(global_id, frame, tracked_objects)

                        # Save snapshot to database WITH ZONE NAME AND GENDER
                        if (self.db_module and global_id not in self.tracked_objects_first_seen and
                                self.tracked_objects_frame_count[global_id] >= self.min_frames_for_storage):
                            current_datetime = datetime.now()
                            full_frame_base64 = self._encode_full_frame_with_single_bbox(frame, tracked_obj)
                            if full_frame_base64:
                                self.tracked_objects_first_seen[global_id] = current_datetime
                                video_path = self.active_video_tracks.get(global_id, None)

                                # Get gender for persons, None for other objects
                                gender = self.tracked_genders.get(global_id, None) if cls == 0 else None

                                self.db_module.save_to_db_queue(
                                    object_id=global_id,
                                    image_base64=full_frame_base64,
                                    timestamp=current_datetime,
                                    object_type=object_type,
                                    object_sub_type=object_sub_type,
                                    camera_name=self.camera_name,
                                    gender=gender,
                                    video_path=video_path,
                                    zone_name=zone_name
                                )

                    # NEW: Save raw frame and detection data to storage
                    if self.frame_storage and tracked_objects:
                        self.frame_storage.save_frame_data(
                            frame=frame,  # Raw clean frame without annotations
                            tracked_objects=tracked_objects,
                            camera_name=self.camera_name,
                            timestamp=datetime.now()
                        )

                # ========== CRITICAL FIX: STOP RECORDINGS FOR DISAPPEARED TRACKS ==========
                # Check for tracks that are no longer detected
                disappeared_tracks = []
                for global_id in list(self.tracked_objects_frame_count.keys()):
                    if global_id not in current_track_ids:
                        # Track is no longer visible
                        self.tracked_objects_frame_count[global_id] = 0

                        # If video was being recorded, mark for stopping
                        if global_id in self.active_video_tracks:
                            disappeared_tracks.append(global_id)

                # Stop video recording for disappeared tracks
                # if self.video_recorder:
                #     for global_id in disappeared_tracks:
                #         if global_id in self.active_video_tracks:
                #             self.logger.info(f"[{self.camera_name}] Track {global_id} disappeared - Stopping recording")
                #             self.video_recorder.stop_recording(global_id)
                #             del self.active_video_tracks[global_id]
                #
                #             # Clean up tracking data
                #             if global_id in self.tracks_last_seen:
                #                 del self.tracks_last_seen[global_id]
                # ==========================================================================

                # Visualization
                if self.enable_visualization:
                    annotated_frame = frame.copy()
                    annotated_frame = self._draw_visualization(annotated_frame, tracked_objects)
                    annotated_frame = self._draw_simple_roi(annotated_frame)
                    cv2.imshow(f"Tracking {self.camera_name}", annotated_frame)
                    cv2.waitKey(1)

                # FPS logging
                self.fps_counter += 1
                if self.fps_counter % self.fps_log_interval == 0:
                    elapsed = time.time() - self.fps_start_time
                    fps = self.fps_log_interval / elapsed if elapsed > 0 else 0
                    self.fps_start_time = time.time()

                time.sleep(self.tracking_sleep)

            except Exception as e:
                self.logger.error(f"[{self.camera_name}] Tracking error: {str(e)}", exc_info=True)
                time.sleep(0.1)

    def cleanup(self):
        """Cleanup resources when stopping tracking"""
        try:
            # Stop frame storage
            if self.frame_storage:
                self.frame_storage.stop()
                stats = self.frame_storage.get_stats()
                self.logger.info(
                    f"[{self.camera_name}] Frame storage stopped - "
                    f"Saved: {stats['frames_saved']}, Failed: {stats['frames_failed']}, "
                    f"Queue size: {stats['queue_size']}"
                )

            # Close visualization windows
            if self.enable_visualization:
                cv2.destroyAllWindows()

            self.logger.info(f"[{self.camera_name}] Tracking manager cleanup completed")

        except Exception as e:
            self.logger.error(f"[{self.camera_name}] Error during cleanup: {e}", exc_info=True)