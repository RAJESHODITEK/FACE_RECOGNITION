import threading
import logging
from src.tracking_module.tracking_manager import TrackingManager
from src.camera_module.camera_manager import CameraManager

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class MultiCameraTrackingManager:
    def __init__(self, camera_managers, db_module=None, camera_names=None,
                 camera_frame_queues=None, roi_dict=None, video_recorder=None):  # ✅ ADDED
        self.camera_managers = camera_managers
        self.db_module = db_module
        self.camera_names = camera_names or {}
        self.camera_frame_queues = camera_frame_queues or []
        self.roi_dict = roi_dict or {}
        self.video_recorder = video_recorder  # ✅ ADDED
        self.tracking_threads = []
        self.tracking_managers = []

    def start_all_tracking(self):
        for cam_id, cam_manager in self.camera_managers.items():
            camera_queue = self.camera_frame_queues[cam_id] if cam_id < len(self.camera_frame_queues) else None
            tracking_manager = TrackingManager(
                cam_manager,
                db_module=self.db_module,
                camera_names=self.camera_names,
                camera_frame_queue=camera_queue,
                roi_dict=self.roi_dict,
                video_recorder=self.video_recorder  # ✅ PASS VIDEO RECORDER
            )
            thread = threading.Thread(target=tracking_manager.track, daemon=True)
            thread.start()
            self.tracking_managers.append(tracking_manager)
            self.tracking_threads.append(thread)

        for thread in self.tracking_threads:
            thread.join()

    def get_tracking_managers(self):
        return self.tracking_managers

    def get_tracking_threads(self):
        return self.tracking_threads