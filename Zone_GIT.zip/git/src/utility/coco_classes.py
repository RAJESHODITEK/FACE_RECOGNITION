# Define COCO classes with original IDs for detection
coco_classes = {
    0: 'person',
    1: 'bicycle',
    2: 'car',
    3: 'motorcycle',
    5: 'bus',
    7: 'truck',
    14: 'bird',
    15: 'cat',
    16: 'dog',
    17: 'horse',
    18: 'sheep',
    19: 'cow',
    20: 'elephant',
    43: 'knife',
    67: 'cell phone'
}

# Mapping from UI IDs (sequential) to original COCO IDs
ui_to_coco_id = {
    1: 0,   # person
    2: 1,   # bicycle
    3: 2,   # car
    4: 3,   # motorcycle
    5: 5,   # bus
    6: 7,   # truck
    7: 14,  # bird
    8: 15,  # cat
    9: 16,  # dog
    10: 17, # horse
    11: 18, # sheep
    12: 19, # cow
    13: 20, # elephant
    14: 43, # knife
    15: 67  # cell phone
}