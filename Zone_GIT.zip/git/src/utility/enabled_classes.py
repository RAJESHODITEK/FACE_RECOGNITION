"""
src/utility/enabled_classes.py

DYNAMIC CLASS ENABLING FROM DATABASE
Loads enabled classes from ZonePolicy table per camera
If Event=1, the object type is enabled for that camera

Table Structure:
- Cam_Id: Camera ID from Camera_Details
- Type: Object type (person, car, truck, etc.)
- Event: 1 = enabled, 0 = disabled
"""
import threading
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

enabled_lock = threading.Lock()

# Camera Index to DB Cam_Id mapping
CAMERA_INDEX_TO_DB_ID = {}

# Camera-specific enabled classes (using camera index)
CAMERA_SPECIFIC_CLASSES = {}

# Mapping of Type from ZonePolicy to COCO class IDs
TYPE_TO_CLASS_ID = {
    'person': [0],
    'bicycle': [1],
    'car': [2],
    'motorcycle': [3],
    'bus': [5],
    'truck': [7],
    'bird': [14],
    'cat': [15],
    'dog': [16],
    'horse': [17],
    'sheep': [18],
    'cow': [19],
    'elephant': [20],
    'knife': [43],
    'cell phone': [67],
    'cellphone': [67],  # Alternative spelling
    'mobile': [67],  # Alternative name
    # Group mappings
    'vehicle': [1, 2, 3, 5, 7],  # All vehicles
    'animal': [14, 15, 16, 17, 18, 19, 20],  # All animals
    'others': [43, 67],  # Knife and cell phone
}

# Reverse mapping for display
CLASS_ID_TO_NAME = {
    0: 'person',
    1: 'bicycle',
    2: 'car',
    3: 'motorcycle',
    5: 'bus',
    7: 'truck',
    14: 'bird',
    15: 'cat',
    16: 'dog',
    17: 'horse',
    18: 'sheep',
    19: 'cow',
    20: 'elephant',
    43: 'knife',
    67: 'cell phone'
}


def initialize_enabled_classes(camera_names_dict, db_module):
    """
    Initialize enabled classes from ZonePolicy table via DBModule.
    Call this ONCE during startup in main.py.

    Args:
        camera_names_dict: {camera_idx: camera_name}
        db_module: Your DBModule instance
    """
    global CAMERA_INDEX_TO_DB_ID, CAMERA_SPECIFIC_CLASSES

    with enabled_lock:
        CAMERA_INDEX_TO_DB_ID.clear()
        CAMERA_SPECIFIC_CLASSES.clear()



        # Build camera index to DB ID mapping
        for cam_idx, cam_name in camera_names_dict.items():
            db_cam_id = db_module.get_camera_id_by_name(cam_name)
            if db_cam_id:
                CAMERA_INDEX_TO_DB_ID[cam_idx] = db_cam_id
                print(f"   Camera {cam_idx} ({cam_name}) _ DB Cam_Id: {db_cam_id}")

        # Load enabled classes from ZonePolicy
        all_camera_classes = db_module.get_all_camera_enabled_classes()

        for db_cam_id, type_names in all_camera_classes.items():
            # Find camera index for this DB Cam_Id
            cam_idx = next((idx for idx, db_id in CAMERA_INDEX_TO_DB_ID.items()
                            if db_id == db_cam_id), None)

            if cam_idx is None:
                continue

            # Convert type names to class IDs
            enabled_classes = []
            for type_name in type_names:
                type_lower = type_name.lower().strip()

                if type_lower in TYPE_TO_CLASS_ID:
                    class_ids = TYPE_TO_CLASS_ID[type_lower]
                    if isinstance(class_ids, list):
                        enabled_classes.extend(class_ids)
                    else:
                        enabled_classes.append(class_ids)
                else:
                    print(f" Unknown type '{type_name}' in ZonePolicy for Cam_Id {db_cam_id}")

            # Remove duplicates and store
            CAMERA_SPECIFIC_CLASSES[cam_idx] = list(set(enabled_classes))

        for cam_idx, classes in CAMERA_SPECIFIC_CLASSES.items():
            cam_name = camera_names_dict.get(cam_idx, f"Camera_{cam_idx}")
            class_names = [CLASS_ID_TO_NAME.get(cls_id, f"class_{cls_id}") for cls_id in classes]




def is_enabled(cls_id, camera_id):
    """
    Check if a COCO class is enabled for a camera.

    Args:
        cls_id: COCO class ID (int) - e.g., 0 for person, 2 for car
        camera_id: Camera index (int) - NOT the DB Cam_Id

    Returns:
        bool: True if enabled for detection, False otherwise
    """
    with enabled_lock:
        if camera_id not in CAMERA_SPECIFIC_CLASSES:
            # Camera not configured - disable all by default

            return False

        enabled = cls_id in CAMERA_SPECIFIC_CLASSES[camera_id]
        return enabled


def get_enabled_classes_for_camera(camera_id):
    """
    Get all enabled class IDs for a camera.

    Args:
        camera_id: Camera index (int)

    Returns:
        list: List of enabled COCO class IDs
    """
    with enabled_lock:
        return CAMERA_SPECIFIC_CLASSES.get(camera_id, []).copy()


def get_enabled_class_names_for_camera(camera_id):
    """
    Get all enabled class names for a camera.

    Args:
        camera_id: Camera index (int)

    Returns:
        list: List of enabled class names
    """
    class_ids = get_enabled_classes_for_camera(camera_id)
    return [CLASS_ID_TO_NAME.get(cls_id, f"class_{cls_id}") for cls_id in class_ids]


def set_camera_specific_classes(camera_id, class_list):
    """
    Manually override enabled classes for a camera.

    Args:
        camera_id: Camera index (int)
        class_list: List of COCO class IDs to enable
    """
    with enabled_lock:
        CAMERA_SPECIFIC_CLASSES[camera_id] = class_list.copy()



def reload_enabled_classes(camera_names_dict, db_module):
    """
    Reload enabled classes from database (for dynamic updates).

    Args:
        camera_names_dict: {camera_idx: camera_name}
        db_module: Your DBModule instance
    """

    initialize_enabled_classes(camera_names_dict, db_module)


def get_class_name(cls_id):
    """Get display name for a class ID."""
    return CLASS_ID_TO_NAME.get(cls_id, f"class_{cls_id}")


def get_all_camera_configurations():
    """
    Get complete configuration for all cameras.

    Returns:
        dict: {camera_id: [list of enabled class IDs]}
    """
    with enabled_lock:
        return {cam_id: classes.copy() for cam_id, classes in CAMERA_SPECIFIC_CLASSES.items()}


# Debug function
def print_configuration():
    """Print current configuration for debugging"""
    with enabled_lock:
        print("\n" + "=" * 80)
        print("ENABLED CLASSES CONFIGURATION")
        print("=" * 80)

        print("\nCamera Index to DB Cam_Id Mapping:")
        for cam_idx, db_id in CAMERA_INDEX_TO_DB_ID.items():
            print(f"  Camera {cam_idx} → DB Cam_Id: {db_id}")

        print("\nEnabled Classes per Camera:")
        for cam_idx, classes in CAMERA_SPECIFIC_CLASSES.items():
            class_names = [CLASS_ID_TO_NAME.get(cls_id, f"class_{cls_id}") for cls_id in classes]
            print(f"  Camera {cam_idx}: {class_names}")

        print("=" * 80 + "\n")