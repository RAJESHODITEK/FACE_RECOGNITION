class UtilityModule:
    def check_roi_change(self, points, new):
        for a, b in zip(points, new):
            if a != b:
                print("Mismatch:", a, b)
                return True
        return False