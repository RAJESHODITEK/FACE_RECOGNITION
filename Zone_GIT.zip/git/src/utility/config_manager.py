import configparser
import os
import logging


class ConfigManager:
    _instance = None
    _config = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ConfigManager, cls).__new__(cls)
        return cls._instance

    def __init__(self, config_file='config.ini'):
        if self._config is None:
            self._config = configparser.ConfigParser()
            if os.path.exists(config_file):
                self._config.read(config_file)
                logging.info(f"Configuration loaded from {config_file}")
            else:
                logging.warning(f" Config file {config_file} not found, using defaults")

    def get(self, section, key, fallback=None):
        """Get configuration value"""
        try:
            return self._config.get(section, key)
        except (configparser.NoSectionError, configparser.NoOptionError):
            return fallback

    def getint(self, section, key, fallback=0):
        """Get integer configuration value"""
        try:
            return self._config.getint(section, key)
        except (configparser.NoSectionError, configparser.NoOptionError, ValueError):
            return fallback

    def getfloat(self, section, key, fallback=0.0):
        """Get float configuration value"""
        try:
            return self._config.getfloat(section, key)
        except (configparser.NoSectionError, configparser.NoOptionError, ValueError):
            return fallback

    def getboolean(self, section, key, fallback=False):
        """Get boolean configuration value"""
        try:
            return self._config.getboolean(section, key)
        except (configparser.NoSectionError, configparser.NoOptionError, ValueError):
            return fallback


def get_config():
    """Get singleton config manager instance"""
    return ConfigManager()

