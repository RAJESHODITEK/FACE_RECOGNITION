import queue

shared_queue = queue.Queue(maxsize=50)
original_frame_queues = [queue.Queue(maxsize=30) for _ in range(4)]
current_classes = []
vehicle_tracking_details_queue = queue.Queue(maxsize=50)
current_camera_details = {
    "Camera_Name": "",
    "roi_start": 15,
    "roi_end": 90,
    'roi_start_width': 15,
    'roi_end_width': 90,
    "Status": "",
    "rtsp_url": ""
}
all_camera_data = []
muted_ids_list = []
camera_Status_checker = False

# Existing functions remain unchanged
def update_camera_details(Camera_Name, rtsp_url, roi_start, roi_end, roi_start_w, roi_end_w, camera_Status):
    print("--------------------------", Camera_Name, rtsp_url, roi_start, roi_end, roi_start_w, roi_end_w, camera_Status)
    current_camera_details["Camera_Name"] = Camera_Name
    current_camera_details["rtsp_url"] = rtsp_url
    current_camera_details["roi_start"] = int(roi_start)
    current_camera_details["roi_end"] = int(roi_end)
    current_camera_details["roi_start_width"] = int(roi_start_w)
    current_camera_details["roi_end_width"] = int(roi_end_w)
    current_camera_details["Status"] = camera_Status
    print(f"Camera details updated: {current_camera_details}")

def update_all_camera_list(all_camera_data_new):
    if all_camera_data_new:
        all_camera_data.clear()
        for camera in all_camera_data_new:
            camera_info = {
                "Camera_Name": camera.get('name', 'N/A'),
                "roi_start": camera.get('height_start_percentage', '0'),
                'roi_end': camera.get('height_end_percentage', '0'),
                "roi_start_width": camera.get('width_start_percentage', '0'),
                'roi_end_width': camera.get('width_end_percentage', '0'),
                "Status": camera.get('direction', 'N/A'),
                "rtsp_url": camera.get('url', 'N/A')
            }
            all_camera_data.append(camera_info)
        print("all camera data is updated with new data.")

def update_current_class(cur_clss):
    global current_classes
    current_classes = cur_clss
    print(f"Current classes updated: {current_classes}")

def add_class(new_class):
    global current_classes
    if new_class not in current_classes:
        current_classes.append(new_class)
        print(f"Class '{new_class}' added.")
    else:
        print(f"Class '{new_class}' already exists.")

def remove_class(class_to_remove):
    global current_classes
    if class_to_remove in current_classes:
        current_classes.remove(class_to_remove)
        print(f"Class '{class_to_remove}' removed.")
    else:
        print(f"Class '{class_to_remove}' not found.")

def get_all_classes():
    return current_classes

def clear_all_classes():
    global current_classes
    current_classes.clear()
    print("All classes have been cleared.")