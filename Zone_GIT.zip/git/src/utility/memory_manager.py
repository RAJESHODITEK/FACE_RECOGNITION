# src/utility/memory_manager.py - Single memory management solution
import gc
import torch
import threading
import time
import logging
from queue import Empty


class MemoryManager:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    print("Creating new MemoryManager instance")
                    cls._instance = super(MemoryManager, cls).__new__(cls)
        else:
            print("Returning existing MemoryManager instance")
        return cls._instance

    def __init__(self):
        if not hasattr(self, 'initialized'):
            print("Initializing MemoryManager")
            self.initialized = True
            self.camera_managers = []
            self.tracking_managers = []
            self.detection_managers = []
            self.frame_queues = []
            self.clear_interval = 30
            self.max_queue_size = 2
            self.running = False
            self.memory_thread = None
            print(f"MemoryManager initialized with clear_interval={self.clear_interval}s, max_queue_size={self.max_queue_size}")

    def register_camera_manager(self, camera_manager):
        """Register camera manager for memory management"""
        print(f"Registering camera manager: {camera_manager}")
        self.camera_managers.append(camera_manager)
        print(f"Camera managers count: {len(self.camera_managers)}")

    def register_tracking_manager(self, tracking_manager):
        """Register tracking manager for memory management"""
        print(f"Registering tracking manager: {tracking_manager}")
        self.tracking_managers.append(tracking_manager)
        print(f"Tracking managers count: {len(self.tracking_managers)}")

    def register_detection_manager(self, detection_manager):
        """Register detection manager for memory management"""
        print(f"Registering detection manager: {detection_manager}")
        self.detection_managers.append(detection_manager)
        print(f"Detection managers count: {len(self.detection_managers)}")

    def register_frame_queue(self, frame_queue):
        """Register frame queue for memory management"""
        print(f"Registering frame queue: {frame_queue}")
        self.frame_queues.append(frame_queue)
        print(f"Frame queues count: {len(self.frame_queues)}")

    def clear_all_queues(self):
        """Clear all registered queues to prevent memory buildup"""
        print("Starting queue cleanup")
        cleared_count = 0

        # Clear camera manager queues
        for cam_manager in self.camera_managers:
            try:
                print(f"Clearing queues for camera manager: {cam_manager}")
                # Clear frame queue - keep only 1 latest frame
                while cam_manager.frame_queue.qsize() > 1:
                    try:
                        cam_manager.frame_queue.get_nowait()
                        cleared_count += 1
                        print(f"Cleared frame from frame_queue, total cleared: {cleared_count}")
                    except Empty:
                        print("Frame queue empty")
                        break

                # Clear detection queue - keep only 1 latest
                while cam_manager.detection_queue.qsize() > 1:
                    try:
                        cam_manager.detection_queue.get_nowait()
                        cleared_count += 1
                        print(f"Cleared item from detection_queue, total cleared: {cleared_count}")
                    except Empty:
                        print("Detection queue empty")
                        break

                # Clear tracking queue - keep only 1 latest
                while cam_manager.tracking_queue.qsize() > 1:
                    try:
                        cam_manager.tracking_queue.get_nowait()
                        cleared_count += 1
                        print(f"Cleared item from tracking_queue, total cleared: {cleared_count}")
                    except Empty:
                        print("Tracking queue empty")
                        break

            except Exception as e:
                logging.warning(f"Error clearing camera manager queues: {e}")
                print(f"Error clearing camera manager queues: {e}")

        # Clear frame queues used by GUI
        for frame_queue in self.frame_queues:
            try:
                print(f"Clearing frame queue: {frame_queue}")
                while frame_queue.qsize() > self.max_queue_size:
                    try:
                        frame_queue.get_nowait()
                        cleared_count += 1
                        print(f"Cleared item from GUI frame queue, total cleared: {cleared_count}")
                    except Empty:
                        print("GUI frame queue empty")
                        break
            except Exception as e:
                logging.warning(f"Error clearing frame queue: {e}")
                print(f"Error clearing frame queue: {e}")

        print(f"Queue cleanup completed, cleared {cleared_count} items")
        return cleared_count

    def clear_tracking_data(self):
        """Clear accumulated tracking data"""
        print("Starting tracking data cleanup")
        cleared_objects = 0

        for tracking_manager in self.tracking_managers:
            try:
                print(f"Clearing tracking data for: {tracking_manager}")
                # Limit tracked objects in memory
                if hasattr(tracking_manager, 'tracked_objects_first_seen'):
                    if len(tracking_manager.tracked_objects_first_seen) > 100:
                        sorted_objects = sorted(
                            tracking_manager.tracked_objects_first_seen.items(),
                            key=lambda x: x[1],
                            reverse=True
                        )
                        old_count = len(tracking_manager.tracked_objects_first_seen)
                        tracking_manager.tracked_objects_first_seen = dict(sorted_objects[:50])
                        cleared_objects += (old_count - 50)
                        print(f"Cleared {old_count - 50} tracked objects, kept 50 recent")

                # Limit track maps
                if hasattr(tracking_manager, 'track_maps'):
                    for cls in list(tracking_manager.track_maps.keys()):
                        if len(tracking_manager.track_maps[cls]) > 20:
                            track_items = list(tracking_manager.track_maps[cls].items())
                            old_count = len(tracking_manager.track_maps[cls])
                            tracking_manager.track_maps[cls] = dict(track_items[-10:])
                            cleared_objects += (old_count - 10)
                            print(f"Cleared {old_count - 10} track maps for class {cls}, kept 10 recent")

            except Exception as e:
                logging.warning(f"Error clearing tracking data: {e}")
                print(f"Error clearing tracking data: {e}")

        print(f"Tracking data cleanup completed, cleared {cleared_objects} objects")
        return cleared_objects

    def clear_gpu_memory(self):
        """Clear GPU memory if CUDA is available"""
        print("Starting GPU memory cleanup")
        try:
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                torch.cuda.synchronize()
                print("GPU memory cleared successfully")
                return True
            else:
                print("CUDA not available, skipping GPU memory cleanup")
        except Exception as e:
            logging.warning(f"Error clearing GPU memory: {e}")
            print(f"Error clearing GPU memory: {e}")
        return False

    def force_garbage_collection(self):
        """Force Python garbage collection"""
        print("Starting garbage collection")
        try:
            collected = gc.collect()
            print(f"Garbage collection completed, collected {collected} objects")
            return collected
        except Exception as e:
            logging.warning(f"Error in garbage collection: {e}")
            print(f"Error in garbage collection: {e}")
            return 0

    def perform_full_memory_cleanup(self):
        """Perform comprehensive memory cleanup"""
        print("Starting full memory cleanup")
        try:
            cleared_queues = self.clear_all_queues()
            cleared_objects = self.clear_tracking_data()
            gpu_cleared = self.clear_gpu_memory()
            collected = self.force_garbage_collection()

            logging.info(f"Memory cleanup completed:")
            logging.info(f"  - Cleared {cleared_queues} queue items")
            logging.info(f"  - Cleared {cleared_objects} tracking objects")
            logging.info(f"  - GPU memory cleared: {gpu_cleared}")
            logging.info(f"  - Garbage collected: {collected} objects")
            print(f"Full memory cleanup completed: {cleared_queues} queue items, {cleared_objects} tracking objects, GPU cleared: {gpu_cleared}, {collected} objects collected")

            return True

        except Exception as e:
            logging.error(f"Error in full memory cleanup: {e}")
            print(f"Error in full memory cleanup: {e}")
            return False

    def _memory_cleanup_loop(self):
        """Background thread for periodic memory cleanup"""
        print("Starting memory cleanup loop")
        while self.running:
            try:
                print(f"Sleeping for {self.clear_interval} seconds")
                time.sleep(self.clear_interval)
                if self.running:
                    print("Performing scheduled memory cleanup")
                    self.perform_full_memory_cleanup()
            except Exception as e:
                logging.error(f"Error in memory cleanup loop: {e}")
                print(f"Error in memory cleanup loop: {e}")
                time.sleep(5)

    def start_automatic_cleanup(self):
        """Start automatic memory cleanup in background thread"""
        print("Attempting to start automatic cleanup")
        if not self.running:
            self.running = True
            self.memory_thread = threading.Thread(
                target=self._memory_cleanup_loop,
                daemon=True,
                name="MemoryManager"
            )
            self.memory_thread.start()

            print(f"Memory manager started, cleanup every {self.clear_interval} seconds")
        else:
            print("Automatic cleanup already running")

    def stop_automatic_cleanup(self):
        """Stop automatic memory cleanup"""
        print("Attempting to stop automatic cleanup")
        self.running = False
        if self.memory_thread and self.memory_thread.is_alive():
            print("Waiting for memory thread to join")
            self.memory_thread.join(timeout=5)
        logging.info("Memory manager stopped")
        print("Memory manager stopped")

    def manual_cleanup(self):
        """Manually trigger memory cleanup"""
        print("Triggering manual memory cleanup")
        return self.perform_full_memory_cleanup()


def get_memory_manager():
    """Get the singleton memory manager instance"""
    print("Getting MemoryManager instance")
    return MemoryManager()