import numpy as np
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def point_in_polygon(x, y, polygon):
    """Check if point (x, y) is inside a polygon defined by a list of (x, y) points"""
    try:
        n = len(polygon)
        if n < 3:
            logging.warning(f"Invalid polygon with {n} points")
            return False
        inside = False
        j = n - 1
        for i in range(n):
            if ((polygon[i][1] > y) != (polygon[j][1] > y)) and \
               (x < (polygon[j][0] - polygon[i][0]) * (y - polygon[i][1]) / (polygon[j][1] - polygon[i][1] + 1e-10) + polygon[i][0]):
                inside = not inside
            j = i
        return inside
    except Exception as e:
        logging.error(f"Error in point_in_polygon: {e}")
        return False