# Enhanced src/utility/roi_update_manager.py
import logging
import threading


class ROIUpdateManager:
    """
    Singleton class to manage ROI updates between GUI, detection, and tracking modules
    """
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if hasattr(self, '_initialized') and self._initialized:
            return

        self.detection_manager = None
        self.tracking_manager = None
        self.shared_roi_dict = {}  # NEW: Shared ROI dict for tracking visualization
        self._initialized = True
        logging.info("ROI Update Manager initialized")

    @classmethod
    def get_instance(cls):
        """Get singleton instance"""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def set_detection_manager(self, detection_manager):
        """Set reference to the multi-camera detection manager"""
        self.detection_manager = detection_manager
        logging.info("Detection manager reference set in ROI Update Manager")

    def set_tracking_manager(self, tracking_manager):
        """Set reference to the multi-camera tracking manager"""
        self.tracking_manager = tracking_manager
        logging.info("Tracking manager reference set in ROI Update Manager")

    def set_shared_roi_dict(self, roi_dict):
        """Set reference to shared ROI dictionary"""
        self.shared_roi_dict = roi_dict
        logging.info("Shared ROI dict reference set in ROI Update Manager")

    def update_roi(self, camera_name, new_roi):
        """Update ROI for a specific camera in both detection and tracking"""
        success = True

        # Update detection manager
        if self.detection_manager:
            detection_success = self.detection_manager.update_camera_roi(camera_name, new_roi)
            if detection_success:
                logging.info(f"Successfully updated ROI in detection manager for camera {camera_name}")
            else:
                logging.error(f"Failed to update ROI in detection manager for camera {camera_name}")
                success = False
        else:
            logging.warning("Detection manager not set. ROI update queued for later.")
            success = False

        # Update shared ROI dict for tracking visualization
        if self.shared_roi_dict is not None:
            self.shared_roi_dict[camera_name] = new_roi
            logging.info(f"Successfully updated shared ROI dict for tracking visualization: {camera_name}")
        else:
            logging.warning("Shared ROI dict not set. Tracking visualization may not update.")

        return success