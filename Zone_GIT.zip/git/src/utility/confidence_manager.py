# src/utility/confidence_manager.py
import json
import os
import threading
from src.utility.coco_classes import coco_classes

confidence_lock = threading.Lock()

default_confidence_values = {
    0: 0.3,   # person
    1: 0.3,   # bicycle
    2: 0.3,   # car
    3: 0.3,   # motorcycle
    5: 0.3,   # bus
    7: 0.3,   # truck
    14: 0.5,  # bird
    15: 0.5,  # cat
    16: 0.5,  # dog
    17: 0.5,  # horse
    18: 0.5,  # sheep
    19: 0.5,  # cow
    20: 0.3,  # elephant
    43: 0.2,  # knife (high confidence for security)
    67: 0.2   # cell phone
}

# Load confidence values from JSON file
confidence_file = "object_confidence.json"
object_confidence = default_confidence_values.copy()

if os.path.exists(confidence_file):
    try:
        with open(confidence_file, 'r') as f:
            saved_confidence = json.load(f)
        for k, v in saved_confidence.items():
            object_confidence[int(k)] = float(v)
        print(f"Loaded confidence values from {confidence_file}")
    except Exception as e:
        print(f"Error loading confidence values: {e}, using defaults")

def get_confidence_for_class(cls_id):
    """Get confidence threshold for a specific class ID"""
    with confidence_lock:
        return object_confidence.get(cls_id, 0.5)

def update_confidence_for_class(cls_id, confidence_value):
    """Update confidence threshold for a specific class"""
    with confidence_lock:
        object_confidence[cls_id] = max(0.1, min(1.0, confidence_value))
        save_confidence_values()

def save_confidence_values():
    """Save current confidence values to JSON file"""
    try:
        with open(confidence_file, 'w') as f:
            json_data = {str(k): v for k, v in object_confidence.items()}
            json.dump(json_data, f, indent=2)
    except Exception as e:
        print(f"Error saving confidence values: {e}")

def get_all_confidence_values():
    """Get all current confidence values"""
    with confidence_lock:
        return object_confidence.copy()