import time
import cv2
import numpy as np
import base64
import math
from datetime import datetime
from collections import defaultdict, Counter
import logging
from src.camera_module.camera_manager import CameraManager
from src.tracking_module.sort import Sort
from src.utility.coco_classes import coco_classes, ui_to_coco_id
from ultralytics import YOLO
import torch

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class TrackingManager:
    def __init__(self, camera_manager: CameraManager, db_module=None, camera_names=None, camera_frame_queue=None,
                 roi_dict=None):
        self.objcamera_manager = camera_manager
        self.tracking_queue = self.objcamera_manager.tracking_queue
        self.db_module = db_module
        self.camera_names = camera_names or {}
        self.camera_frame_queue = camera_frame_queue
        self.tracked_objects_first_seen = {}
        self.trackers = {}
        self.track_maps = defaultdict(dict)
        self.tracked_genders = {}  # Store {global_id: (gender, confidence, last_updated_frame)}
        self.gender_predictions = {}  # Store {global_id: [(gender, confidence), ...]} for voting
        self.max_predictions = 10  # Number of predictions for majority voting
        self.frame_count = 0  # Track frame count for periodic gender re-detection
        self.gender_redetect_interval = 30  # Re-detect gender every 30 frames

        # Store camera info for dynamic ROI fetching
        self.camera_name = self.camera_names.get(camera_manager.cam_idx, f"Camera_{camera_manager.cam_idx}")
        self.roi_dict = roi_dict or {}  # Store reference to ROI dict

        # Animation and visual effects variables
        self.roi_animation_time = time.time()  # For animation effects
        self.roi_pulse_phase = 0  # For pulsing effects
        self.scan_line_offset = 0  # For scan line animation
        self.corner_pulse_offset = 0  # For corner animation timing

        # Initialize gender detection model
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.gender_model = YOLO("gender.pt")  # Load pre-trained gender model

    def _encode_frame_region(self, frame, box):
        x1, y1, x2, y2 = box
        x1, y1 = max(0, x1 - 10), max(0, y1 - 10)
        x2, y2 = x2 + 10, y2 + 10
        region = frame[y1:y2, x1:x2]
        if region.size == 0:
            return None
        height, width = region.shape[:2]
        if height > 200 or width > 200:
            scale = min(200 / height, 200 / width)
            region = cv2.resize(region, (int(width * scale), int(height * scale)), interpolation=cv2.INTER_AREA)
        _, buffer = cv2.imencode('.jpg', region, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
        return base64.b64encode(buffer).decode('utf-8')

    def _frame_quality_check(self, region):
        """Check if the frame region is suitable for gender detection"""
        try:
            if region.size == 0:
                return False
            height, width = region.shape[:2]
            if height < 50 or width < 50:  # Minimum size requirement
                return False
            gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
            brightness = np.mean(gray)
            if brightness < 30 or brightness > 220:  # Avoid too dark or too bright images
                return False
            return True
        except Exception as e:
            logging.warning(f"Frame quality check error: {e}")
            return False

    def get_gender_yolo(self, img_bgr):
        """Detect gender using YOLO model with confidence threshold of 0.9"""
        try:
            results = self.gender_model.predict(img_bgr, conf=0.9, imgsz=180, verbose=False, device=self.device)
            if not results or len(results[0].boxes) == 0:
                return "Unknown", 0.0
            box = results[0].boxes[0]
            cls = int(box.cls[0].item())
            confidence = float(box.conf[0].item())
            gender = "Male" if cls == 1 else "Female"
            return gender, confidence
        except Exception as e:
            logging.warning(f"Gender detection error: {e}")
            return "Unknown", 0.0

    def _get_majority_gender(self, predictions):
        """Determine the majority gender from a list of predictions"""
        if not predictions:
            return "Unknown", 0.0
        # Count votes for each gender
        gender_counts = Counter(gender for gender, _ in predictions)
        most_common_gender, vote_count = gender_counts.most_common(1)[0]
        # If there's a tie or insufficient votes, use the highest confidence
        if len(gender_counts) > 1 and vote_count <= len(predictions) / 2:
            max_conf_gender = max(predictions, key=lambda x: x[1], default=("Unknown", 0.0))
            return max_conf_gender[0], max_conf_gender[1]
        # Return the majority gender with the average confidence of its votes
        avg_conf = sum(conf for gender, conf in predictions if gender == most_common_gender) / vote_count
        return most_common_gender, avg_conf

    def _get_current_roi(self):
        """Get current ROI data dynamically from database or ROI dict"""
        try:
            if self.roi_dict and self.camera_name in self.roi_dict:
                return self.roi_dict[self.camera_name]
            if self.db_module:
                pass
            return None
        except Exception as e:
            logging.warning(f"Error getting current ROI: {e}")
            return None

    def _create_gradient_overlay(self, frame, x1, y1, x2, y2, color1, color2, alpha=0.3):
        """Create a beautiful gradient overlay for the ROI"""
        h, w = frame.shape[:2]
        overlay = frame.copy()
        roi_height = y2 - y1
        roi_width = x2 - x1
        if roi_height <= 0:
            return frame
        for i in range(roi_height):
            ratio = i / max(roi_height - 1, 1)
            smooth_ratio = 0.5 * (1 + math.sin(math.pi * (ratio - 0.5)))
            blended_color = [
                int(color1[j] * (1 - smooth_ratio) + color2[j] * smooth_ratio)
                for j in range(3)
            ]
            if y1 + i < h and y1 + i >= 0:
                cv2.rectangle(overlay, (x1, y1 + i), (x2, min(y1 + i + 1, h)), blended_color, -1)
        return cv2.addWeighted(frame, 1 - alpha, overlay, alpha, 0)

    def _draw_animated_corners(self, frame, x1, y1, x2, y2, color, corner_size=30, thickness=4):
        """Draw animated corner brackets with glow effect"""
        current_time = time.time()
        pulse = (math.sin(current_time * 2) + 1) / 2
        animated_corner_size = int(corner_size + pulse * 10)
        glow_thickness = thickness + int(pulse * 2)
        glow_color = tuple(min(255, c + 50) for c in color)
        corners = [
            [(x1, y1), (x1 + animated_corner_size, y1), (x1, y1 + animated_corner_size)],
            [(x2, y1), (x2 - animated_corner_size, y1), (x2, y1 + animated_corner_size)],
            [(x1, y2), (x1 + animated_corner_size, y2), (x1, y2 - animated_corner_size)],
            [(x2, y2), (x2 - animated_corner_size, y2), (x2, y2 - animated_corner_size)]
        ]
        for corner in corners:
            cv2.line(frame, corner[0], corner[1], glow_color, glow_thickness + 2, cv2.LINE_AA)
            cv2.line(frame, corner[0], corner[2], glow_color, glow_thickness + 2, cv2.LINE_AA)
        for corner in corners:
            cv2.line(frame, corner[0], corner[1], color, thickness, cv2.LINE_AA)
            cv2.line(frame, corner[0], corner[2], color, thickness, cv2.LINE_AA)

    def _draw_modern_label(self, frame, x1, y1, x2, y2, text="REGION OF INTEREST"):
        """Draw a modern, glassy label with animations"""
        current_time = time.time()
        pulse = (math.sin(current_time * 1.5) + 1) / 2
        primary_color = (80, 200, 255)
        accent_color = (255, 150, 50)
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 0.8
        thickness = 2
        (text_width, text_height), baseline = cv2.getTextSize(text, font, font_scale, thickness)
        label_x = x1 + 15
        label_y = y1 - 20
        if label_y - text_height < 0:
            label_y = y1 + text_height + 25
        padding = 15
        bg_x1 = max(0, label_x - padding)
        bg_y1 = max(0, label_y - text_height - padding)
        bg_x2 = min(frame.shape[1], label_x + text_width + padding)
        bg_y2 = min(frame.shape[0], label_y + padding)
        overlay = frame.copy()
        gradient_color1 = tuple(int(c * (0.7 + pulse * 0.3)) for c in primary_color)
        gradient_color2 = tuple(int(c * (0.4 + pulse * 0.2)) for c in accent_color)
        cv2.rectangle(overlay, (bg_x1, bg_y1), (bg_x2, bg_y2), gradient_color1, -1)
        if bg_x2 > bg_x1 + 4 and bg_y2 > bg_y1 + 4:
            cv2.rectangle(overlay, (bg_x1 + 2, bg_y1 + 2), (bg_x2 - 2, bg_y2 - 2), gradient_color2, -1)
        frame = cv2.addWeighted(frame, 0.6, overlay, 0.4, 0)
        border_color = tuple(min(255, c + 100) for c in primary_color)
        cv2.rectangle(frame, (bg_x1, bg_y1), (bg_x2, bg_y2), border_color, 2, cv2.LINE_AA)
        cv2.rectangle(frame, (bg_x1 - 1, bg_y1 - 1), (bg_x2 + 1, bg_y2 + 1), (255, 255, 255), 1, cv2.LINE_AA)
        text_color = (255, 255, 255)
        shadow_color = (0, 0, 0)
        cv2.putText(frame, text, (label_x + 2, label_y + 2), font, font_scale, shadow_color, thickness + 1, cv2.LINE_AA)
        cv2.putText(frame, text, (label_x, label_y), font, font_scale, primary_color, thickness + 2, cv2.LINE_AA)
        cv2.putText(frame, text, (label_x, label_y), font, font_scale, text_color, thickness, cv2.LINE_AA)

    def _draw_roi_on_frame(self, frame):
        """Draw ultra-stylish ROI with modern effects, animations, and glassmorphism (without grid)"""
        current_roi = self._get_current_roi()
        if not current_roi:
            return frame
        try:
            h, w = frame.shape[:2]
            sx = int(w * current_roi['start_width_percent'] / 100)
            ex = int(w * current_roi['end_width_percent'] / 100)
            sy = int(h * current_roi['start_height_percent'] / 100)
            ey = int(h * current_roi['end_height_percent'] / 100)
            if sx >= ex or sy >= ey or sx < 0 or sy < 0 or ex > w or ey > h:
                return frame
            current_time = time.time()
            primary_color = (255, 165, 0)
            secondary_color = (255, 200, 100)
            accent_color = (80, 200, 255)
            gradient_color1 = (200, 100, 50)
            gradient_color2 = (255, 180, 100)
            frame = self._create_gradient_overlay(frame, sx, sy, ex, ey, gradient_color1, gradient_color2, 0.15)
            self._draw_animated_corners(frame, sx, sy, ex, ey, primary_color, corner_size=40, thickness=4)
            pulse = (math.sin(current_time * 2.5) + 1) / 2
            border_thickness = int(2 + pulse * 2)
            pulsing_color = tuple(int(c * (0.8 + pulse * 0.2)) for c in primary_color)
            cv2.rectangle(frame, (sx - 2, sy - 2), (ex + 2, ey + 2), (255, 255, 255), 1, cv2.LINE_AA)
            cv2.rectangle(frame, (sx, sy), (ex, ey), pulsing_color, border_thickness, cv2.LINE_AA)
            self._draw_modern_label(frame, sx, sy, ex, ey)
            status_x = min(ex - 30, w - 30)
            status_y = min(sy + 30, h - 30)
            if status_x > 0 and status_y > 0:
                status_radius = int(8 + pulse * 3)
                cv2.circle(frame, (status_x, status_y), status_radius + 2, (255, 255, 255), 2, cv2.LINE_AA)
                cv2.circle(frame, (status_x, status_y), status_radius, (0, 255, 0), -1, cv2.LINE_AA)
                cv2.putText(frame, "ACTIVE", (max(0, status_x - 35), min(h - 5, status_y + 20)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1, cv2.LINE_AA)
        except Exception as e:
            logging.warning(f"Error drawing stylish ROI on frame: {e}")
        return frame

    def track(self):
        self.frame_count = 0
        while True:
            if self.objcamera_manager.detection_queue.empty():
                time.sleep(0.1)
                continue
            try:
                data = self.objcamera_manager.detection_queue.get()
                frame = data["frame"]
                detections = data["detections"]
                self.frame_count += 1
                grouped_dets = defaultdict(list)
                for det in detections:
                    cls = det["cls"]
                    x1, y1, x2, y2 = det["box"]
                    conf = det["conf"]
                    grouped_dets[cls].append([x1, y1, x2, y2, conf])
                tracked_objects = []
                current_time = datetime.now()
                annotated_frame = frame.copy()
                def map_class_to_category(cls_id):
                    if cls_id == 0:
                        return "person"
                    elif cls_id in [1, 2, 3, 5, 7]:
                        return "vehicle"
                    elif cls_id in [14, 15, 16, 17, 18, 19, 20]:
                        return "animal"
                    else:
                        return coco_classes.get(cls_id, "unknown")
                for cls, dets_list in grouped_dets.items():
                    dets_np = np.array(dets_list) if len(dets_list) > 0 else np.empty((0, 5))
                    if cls not in self.trackers:
                        self.trackers[cls] = Sort(max_age=50, min_hits=3, iou_threshold=0.2)
                    tracker = self.trackers[cls]
                    tracks = tracker.update(dets_np)
                    for track in tracks:
                        x1, y1, x2, y2, local_id = map(int, track)
                        if local_id not in self.track_maps[cls]:
                            global_id = self.db_module.get_next_track_id()
                            self.track_maps[cls][local_id] = global_id
                        global_id = self.track_maps[cls][local_id]
                        image_base64 = self._encode_frame_region(frame, [x1, y1, x2, y2])
                        Object_Type = map_class_to_category(cls)
                        gender = "Unknown"
                        confidence = 0.0
                        if self.db_module and global_id not in self.tracked_objects_first_seen:
                            self.tracked_objects_first_seen[global_id] = current_time
                            if image_base64:
                                initial_gender = "Unknown" if cls == 0 else None
                                self.db_module.save_to_db_queue(
                                    object_id=global_id,
                                    Country="Unknown",
                                    image_base64=image_base64,
                                    Is_Recognized=False,
                                    timestamp=current_time,
                                    Status="Active",
                                    Alarm=True,
                                    Acknowledgment_Message="",
                                    Acknowledgment_Time=None,
                                    Object_Type=Object_Type,
                                    camera_id=self.objcamera_manager.cam_idx,
                                    Camera_Names=self.camera_names,
                                    gender=initial_gender
                                )
                                logging.info(
                                    f"New {Object_Type} tracked - Numeric ID: {global_id}, "
                                    f"Camera: {self.objcamera_manager.cam_idx}, Initial Gender: {initial_gender or 'N/A'}"
                                )
                        if cls == 0:  # Person class
                            person_crop = frame[y1:y2, x1:x2]
                            if self._frame_quality_check(person_crop):
                                with torch.no_grad():
                                    pred_gender, pred_confidence = self.get_gender_yolo(person_crop)
                                if global_id not in self.gender_predictions:
                                    self.gender_predictions[global_id] = []
                                if pred_gender != "Unknown":
                                    self.gender_predictions[global_id].append((pred_gender, pred_confidence))
                                # Limit to max_predictions
                                if len(self.gender_predictions[global_id]) > self.max_predictions:
                                    self.gender_predictions[global_id].pop(0)
                                # Determine majority gender
                                current_gender_info = self.tracked_genders.get(global_id, ("Unknown", 0.0, -1))
                                if (len(self.gender_predictions[global_id]) >= self.max_predictions or
                                    self.frame_count - current_gender_info[2] >= self.gender_redetect_interval):
                                    gender, confidence = self._get_majority_gender(self.gender_predictions[global_id])
                                    self.tracked_genders[global_id] = (gender, confidence, self.frame_count)
                                    logging.info(f"Majority gender for ID {global_id}: {gender} (Confidence: {confidence:.2f}, Votes: {len(self.gender_predictions[global_id])})")
                                    # Update DB with voted gender
                                    if gender != "Unknown":
                                        self.db_module.update_gender(global_id, gender)
                                    # Reset predictions for next voting cycle
                                    self.gender_predictions[global_id] = []
                            else:
                                logging.debug(f"Frame for ID {global_id} did not pass quality check")
                        color = (0, 255, 0)
                        border_color = (255, 255, 255)
                        cv2.rectangle(annotated_frame, (x1, y1), (x2, y2), border_color, 2, lineType=cv2.LINE_AA)
                        cv2.rectangle(annotated_frame, (x1, y1), (x2, y2), color, 2, lineType=cv2.LINE_AA)
                        gender_str = self.tracked_genders.get(global_id, ("Unknown", 0.0, -1))[0] if cls == 0 else ""
                        label = f"{map_class_to_category(cls)} ID {global_id}{f' {gender_str}' if gender_str else ''}"
                        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
                        cv2.rectangle(annotated_frame, (x1, y1 - th - 10), (x1 + tw + 6, y1), color, -1)
                        cv2.putText(annotated_frame, label, (x1 + 3, y1 - 5),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0),
                                    2, lineType=cv2.LINE_AA)
                        tracked_objects.append({"track_id": global_id, "box": [x1, y1, x2, y2], "cls": cls})
                annotated_frame = self._draw_roi_on_frame(annotated_frame)
                if self.camera_frame_queue:
                    try:
                        self.camera_frame_queue.put_nowait(annotated_frame.copy())
                    except:
                        try:
                            self.camera_frame_queue.get_nowait()
                            self.camera_frame_queue.put_nowait(annotated_frame.copy())
                        except:
                            pass
                logging.info(f"Camera {self.objcamera_manager.cam_idx}: Tracked {len(tracked_objects)} objects")
                time.sleep(0.01)
            except Exception as e:
                logging.error(f"Tracking error: {str(e)}")
                try:
                    for tracker in self.trackers.values():
                        tracker.update(np.empty((0, 5)))
                except:
                    pass