import cv2
import threading
import queue
import logging
import os
from datetime import datetime
from pathlib import Path
import time
from collections import defaultdict

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


class VideoRecordingModule:
    """
    Handles video recording for tracked objects with folder structure:
    D:/ZONE_VIDEOS/DD-MM-YYYY/camera_name/trackid_timestamp.avi
    """

    def __init__(self, base_path=r"D:\ZONE_VIDEOS", fps=20, codec='XVID'):
        """
        Initialize the video recording module

        Args:
            base_path: Base directory for video storage
            fps: Frames per second for video recording
            codec: Video codec (XVID, MJPG, mp4v, etc.)
        """
        self.base_path = base_path
        self.fps = fps
        self.codec = cv2.VideoWriter_fourcc(*codec)

        # Ensure base directory exists
        os.makedirs(self.base_path, exist_ok=True)
        logging.info(f"Video storage base path: {self.base_path}")

        # Video writers dictionary: {(camera_name, track_id): writer_info}
        self.video_writers = {}
        self.writer_lock = threading.Lock()

        # Recording queue for async processing
        self.recording_queue = queue.Queue(maxsize=500)
        self.recording_thread = threading.Thread(target=self._process_recording_queue, daemon=True)
        self.recording_thread.start()

        # Track recording metadata
        self.recording_metadata = defaultdict(dict)

        # Configuration
        self.max_recording_duration = 300  # 5 minutes max per video
        self.frame_buffer_size = 30  # Buffer frames before writing
        self.min_frames_before_recording = 5  # Start recording after N frames

        # Track frame counts to determine when to start recording
        self.track_frame_counts = defaultdict(int)

        logging.info("Video Recording Module initialized")

    def start_recording(self, camera_name, track_id, frame_width, frame_height, timestamp=None):
        """
        Start recording for a specific tracked object

        Args:
            camera_name: Name of the camera
            track_id: Track ID of the object
            frame_width: Width of the video frame
            frame_height: Height of the video frame
            timestamp: Optional timestamp (defaults to current time)

        Returns:
            str: Video file path if successful, None otherwise
        """
        try:
            with self.writer_lock:
                key = (camera_name, track_id)

                # Check if already recording
                if key in self.video_writers:
                    logging.debug(f"Already recording for {camera_name}, Track ID {track_id}")
                    return self.video_writers[key]['path']

                # Create timestamp
                if timestamp is None:
                    timestamp = datetime.now()

                # Generate video path
                video_path = self._generate_video_path(camera_name, track_id, timestamp)

                # Create directory if needed
                os.makedirs(os.path.dirname(video_path), exist_ok=True)

                # Create video writer
                writer = cv2.VideoWriter(
                    video_path,
                    self.codec,
                    self.fps,
                    (frame_width, frame_height)
                )

                if not writer.isOpened():
                    logging.error(f"Failed to open video writer for {video_path}")
                    return None

                # Store writer info
                self.video_writers[key] = {
                    'writer': writer,
                    'path': video_path,
                    'start_time': time.time(),
                    'frame_count': 0,
                    'frame_buffer': []
                }

                # Store metadata
                self.recording_metadata[key] = {
                    'camera_name': camera_name,
                    'track_id': track_id,
                    'start_timestamp': timestamp,
                    'frame_width': frame_width,
                    'frame_height': frame_height
                }

                logging.info(f"Started recording: {video_path}")
                return video_path

        except Exception as e:
            logging.error(f"Error starting recording for {camera_name}, Track ID {track_id}: {e}")
            return None

    def process_tracked_object(self, camera_name, track_id, frame, is_first_detection=False):
        """
        Process a tracked object and handle video recording
        Call this method for each tracked object in each frame

        Args:
            camera_name: Name of the camera
            track_id: Track ID of the object
            frame: Full frame (numpy array)
            is_first_detection: True if this is a new track
        """
        try:
            key = (camera_name, track_id)

            # Increment frame count for this track
            self.track_frame_counts[key] += 1

            # Check if we should start recording
            if (self.track_frame_counts[key] >= self.min_frames_before_recording and
                    not self.is_recording(camera_name, track_id)):

                h, w = frame.shape[:2]
                video_path = self.start_recording(camera_name, track_id, w, h)
                if video_path:
                    logging.info(f"Auto-started recording for {camera_name}, Track ID {track_id}")

            # Add frame to recording if active
            if self.is_recording(camera_name, track_id):
                self.add_frame(camera_name, track_id, frame)

        except Exception as e:
            logging.error(f"Error processing tracked object: {e}")

    def add_frame(self, camera_name, track_id, frame):
        """
        Add a frame to the recording queue

        Args:
            camera_name: Name of the camera
            track_id: Track ID of the object
            frame: Frame to record (numpy array)
        """
        try:
            key = (camera_name, track_id)

            # Check if recording exists
            with self.writer_lock:
                if key not in self.video_writers:
                    return

            # Add to queue for async processing
            try:
                self.recording_queue.put_nowait((camera_name, track_id, frame.copy()))
            except queue.Full:
                logging.warning(f"Recording queue full, dropping frame for {camera_name}, Track ID {track_id}")

        except Exception as e:
            logging.error(f"Error adding frame to recording: {e}")

    def stop_recording(self, camera_name, track_id):
        """
        Stop recording for a specific tracked object

        Args:
            camera_name: Name of the camera
            track_id: Track ID of the object

        Returns:
            str: Path to the saved video file
        """
        try:
            with self.writer_lock:
                key = (camera_name, track_id)

                if key not in self.video_writers:
                    logging.debug(f"No active recording for {camera_name}, Track ID {track_id}")
                    return None

                writer_info = self.video_writers[key]

                # Write any remaining buffered frames
                for buffered_frame in writer_info['frame_buffer']:
                    writer_info['writer'].write(buffered_frame)

                # Release writer
                writer_info['writer'].release()

                video_path = writer_info['path']
                frame_count = writer_info['frame_count']
                duration = time.time() - writer_info['start_time']

                # Clean up
                del self.video_writers[key]
                if key in self.track_frame_counts:
                    del self.track_frame_counts[key]

                logging.info(
                    f"Stopped recording: {video_path} "
                    f"({frame_count} frames, {duration:.2f}s)"
                )

                return video_path

        except Exception as e:
            logging.error(f"Error stopping recording for {camera_name}, Track ID {track_id}: {e}")
            return None

    def on_track_lost(self, camera_name, track_id):
        """
        Call this when a track is lost to stop recording

        Args:
            camera_name: Name of the camera
            track_id: Track ID that was lost
        """
        if self.is_recording(camera_name, track_id):
            video_path = self.stop_recording(camera_name, track_id)
            if video_path:
                logging.info(f"Track lost - stopped recording: {video_path}")

    def _process_recording_queue(self):
        """Process the recording queue (runs in separate thread)"""
        while True:
            try:
                camera_name, track_id, frame = self.recording_queue.get(timeout=1.0)

                with self.writer_lock:
                    key = (camera_name, track_id)

                    if key not in self.video_writers:
                        continue

                    writer_info = self.video_writers[key]

                    # Add to buffer
                    writer_info['frame_buffer'].append(frame)

                    # Write buffer if full
                    if len(writer_info['frame_buffer']) >= self.frame_buffer_size:
                        for buffered_frame in writer_info['frame_buffer']:
                            writer_info['writer'].write(buffered_frame)
                            writer_info['frame_count'] += 1
                        writer_info['frame_buffer'].clear()

                    # Check max duration
                    elapsed = time.time() - writer_info['start_time']
                    if elapsed > self.max_recording_duration:
                        logging.warning(
                            f"Max duration reached for {camera_name}, Track ID {track_id}. "
                            f"Stopping recording."
                        )
                        # Note: We'll stop it on next frame processing to avoid deadlock

                self.recording_queue.task_done()

            except queue.Empty:
                continue
            except Exception as e:
                logging.error(f"Error processing recording queue: {e}")

    def _generate_video_path(self, camera_name, track_id, timestamp):
        """
        Generate video file path following the pattern:
        base_path/DD-MM-YYYY/camera_name/trackid_timestamp.avi

        Args:
            camera_name: Name of the camera
            track_id: Track ID
            timestamp: Datetime object

        Returns:
            str: Full path to video file
        """
        # Create date folder (DD-MM-YYYY to match image saving)
        date_str = timestamp.strftime('%d-%m-%Y')

        # Sanitize camera name for folder
        safe_camera_name = camera_name.replace(" ", "_").replace(":", "_").replace("\\", "_").replace("/", "_")

        # Create timestamp string for filename
        timestamp_str = timestamp.strftime('%Y%m%d_%H%M%S')

        # Generate filename: trackid_timestamp.avi
        filename = f"{track_id}_{timestamp_str}.avi"

        # Full path
        full_path = os.path.join(self.base_path, date_str, safe_camera_name, filename)

        return full_path

    def is_recording(self, camera_name, track_id):
        """
        Check if currently recording for a specific object

        Args:
            camera_name: Name of the camera
            track_id: Track ID of the object

        Returns:
            bool: True if recording, False otherwise
        """
        with self.writer_lock:
            return (camera_name, track_id) in self.video_writers

    def get_recording_info(self, camera_name, track_id):
        """
        Get information about an active recording

        Args:
            camera_name: Name of the camera
            track_id: Track ID of the object

        Returns:
            dict: Recording information or None
        """
        with self.writer_lock:
            key = (camera_name, track_id)
            if key not in self.video_writers:
                return None

            writer_info = self.video_writers[key]
            metadata = self.recording_metadata.get(key, {})

            return {
                'path': writer_info['path'],
                'frame_count': writer_info['frame_count'],
                'duration': time.time() - writer_info['start_time'],
                'camera_name': metadata.get('camera_name'),
                'track_id': metadata.get('track_id'),
                'start_timestamp': metadata.get('start_timestamp')
            }

    def get_all_active_recordings(self):
        """
        Get information about all active recordings

        Returns:
            list: List of recording info dictionaries
        """
        with self.writer_lock:
            return [
                self.get_recording_info(camera_name, track_id)
                for camera_name, track_id in self.video_writers.keys()
            ]

    def stop_all_recordings(self):
        """Stop all active recordings"""
        with self.writer_lock:
            keys = list(self.video_writers.keys())

        for camera_name, track_id in keys:
            self.stop_recording(camera_name, track_id)

        logging.info("All recordings stopped")

    def cleanup_old_videos(self, days=30):
        """
        Delete videos older than specified days

        Args:
            days: Number of days to keep videos
        """
        try:
            cutoff_date = datetime.now().timestamp() - (days * 24 * 60 * 60)
            deleted_count = 0

            for root, dirs, files in os.walk(self.base_path):
                for file in files:
                    if file.endswith('.avi'):
                        file_path = os.path.join(root, file)
                        if os.path.getmtime(file_path) < cutoff_date:
                            os.remove(file_path)
                            deleted_count += 1

            logging.info(f"Cleaned up {deleted_count} old videos")

        except Exception as e:
            logging.error(f"Error cleaning up old videos: {e}")


# Usage Example:
"""
# Initialize the module
video_recorder = VideoRecordingModule(base_path=r"D:\ZONE_VIDEOS", fps=20)

# In your tracking loop, for each tracked object:
for tracked_obj in tracked_objects:
    track_id = tracked_obj["track_id"]

    # Process the tracked object (auto-starts recording after min frames)
    video_recorder.process_tracked_object(
        camera_name="Camera_1",
        track_id=track_id,
        frame=current_frame
    )

# When a track is lost:
video_recorder.on_track_lost(camera_name="Camera_1", track_id=lost_track_id)

# To manually stop a recording:
video_path = video_recorder.stop_recording(camera_name="Camera_1", track_id=track_id)

# To stop all recordings (e.g., on shutdown):
video_recorder.stop_all_recordings()

# To cleanup old videos:
video_recorder.cleanup_old_videos(days=30)
"""