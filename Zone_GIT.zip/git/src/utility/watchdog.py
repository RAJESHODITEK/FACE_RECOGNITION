import os
import time
import socket
import struct
import threading
from datetime import datetime
from src.utility.config_manager import get_config


class WatchdogClient:
    def __init__(self):
        config = get_config()
        self.app_name = config.get("WATCH_DOG", "app_name")
        self.exe_path = config.get("WATCH_DOG", "exe_path")
        self.dw_value = os.getpid()
        self.last_msg= ""

        self.host = config.get("WATCH_DOG", "host")
        self.port = int(config.get("WATCH_DOG", "port"))

        self.sock = None
        self.connected = False
        self.first_time = True
        self.running = True

        self.STRUCT_FORMAT = '16s16s128s128sI'
        self.STRUCT_SIZE = struct.calcsize(self.STRUCT_FORMAT)
        self.ini_path = ""

        # Start receive thread safely
        self.thread = threading.Thread(target=self._receive_loop, daemon=True)
        self.thread.start()
        print("[Watchdog] Thread started successfully")

    def encode_struct(self, status: str):
        return struct.pack(
            self.STRUCT_FORMAT,
            self.app_name.encode('utf-8').ljust(16, b'\x00'),
            status.encode('utf-8').ljust(16, b'\x00'),
            self.ini_path.encode('utf-8').ljust(128, b'\x00'),
            self.exe_path.encode('utf-8').ljust(128, b'\x00'),
            self.dw_value
        )

    def connect(self):
        if self.connected and self.sock:
            return True
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.settimeout(3)
            self.sock.connect((self.host, self.port))
            self.sock.settimeout(None)
            self.connected = True
            print(f"[Watchdog] Connected to {self.host}:{self.port}")
            return True
        except Exception as e:
            print(f"[Watchdog] Connection failed: {e}")
            self.cleanup_connection()
            return False

    def send_signal(self, command="Alive"):
        try:
            if not self.connect():
                return
            status = "Start" if self.first_time and command == "Alive" else command
            data = self.encode_struct(status)
            self.sock.sendall(data)
            print(f"[Watchdog] Sent: {status}")
            self.first_time = False
        except Exception as e:
            print(f"[Watchdog] Send failed: {e}")
            self.cleanup_connection()

    def _receive_loop(self):
        print("[Watchdog] Receive loop started")
        while self.running:
            try:
                if not self.connected:
                    if not self.connect():
                        time.sleep(2)
                        continue

                data = self.sock.recv(1024)
                if not data:
                    print("[Watchdog] Disconnected by server")
                    self.cleanup_connection()
                    time.sleep(2)
                    continue

                msg = data.decode('utf-8', errors='ignore')
                self.last_msg = msg
                print(f"[Watchdog] Received: {msg}")

            except Exception as e:
                print(f"[Watchdog] Receive error: {e}")
                self.cleanup_connection()
                time.sleep(2)

        print("[Watchdog] Receive loop stopped")

    def cleanup_connection(self):
        if self.sock:
            try:
                self.sock.close()
            except Exception:
                pass
        self.sock = None
        self.connected = False

    def restart(self):
        print("[Watchdog] Restarting client...")
        self.stop()
        time.sleep(1)
        self.running = True
        self.first_time = True
        self.thread = threading.Thread(target=self._receive_loop, daemon=True)
        self.thread.start()
        self.send_signal("Alive")

    def stop(self):
        print("[Watchdog] Stopping client...")
        self.running = False
        self.cleanup_connection()
        if self.thread.is_alive():
            self.thread.join(timeout=1)
        print("[Watchdog] Stopped")
