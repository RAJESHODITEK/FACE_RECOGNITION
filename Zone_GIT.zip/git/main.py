import sys
import threading
import time
import logging
from pathlib import Path
from datetime import datetime
from src.database_module.database_manager import DBModule
from src.camera_module.multi_camera_manager import MultiCamCameraManager
from src.detection_module.multi_camera_detection_manager import MultiCameraDetectionManager
from src.tracking_module.multi_camera_tracking_manager import MultiCameraTrackingManager
from src.utility.logger import LoggerUtility
from src.video_module.video_manager import TrackVideoManager
from src.utility.config_manager import get_config
from src.utility.enabled_classes import initialize_enabled_classes, print_configuration, reload_enabled_classes
from src.utility.memory_manager import get_memory_manager
from src.utility.watchdog import WatchdogClient


def setup_logging(log_dir_path=None):
    """
    Setup logging to both console and file

    Args:
        log_dir_path: Path to log directory (not file). If None, logs only to console
    """
    # Create formatter
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

    # Get root logger
    logger = LoggerUtility().get_logger(__name__)
    logger.setLevel(logging.INFO)

    # Remove existing handlers
    logger.handlers.clear()

    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # File handler (if path provided)
    if log_dir_path:
        try:
            # Create log directory if it doesn't exist
            log_dir = Path(log_dir_path)
            log_dir.mkdir(parents=True, exist_ok=True)

            # Create log file with timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            log_file = log_dir / f"Zone_Detection_{timestamp}.log"

            # Create file handler with rotation support
            file_handler = logging.FileHandler(log_file, mode='a', encoding='utf-8')
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)

            logger.info(f" Logging initialized - Log file: {log_file}")

        except Exception as e:
            logger.warning(f" Could not create log file: {e}")



def main():
    config = get_config()
    start_time = time.time()

    # Setup logging with directory path from config
    log_dir_path = config.get('LOGGING', 'log_file_path', 'logs')
    setup_logging(log_dir_path)

    logger = logging.getLogger(__name__)

    # Log application info
    app_name = config.get('APP', 'app_name', 'Zone Detection System')
    version = config.get('APP', 'version', '1.0.0')


    # Initialize watchdog
    watchdog = WatchdogClient()
    logger.info(" Watchdog client initialized")

    # Initialize memory manager
    memory_manager = get_memory_manager()
    logger.info(" Memory manager initialized")

    # Initialize database and fetch cameras
    logger.info(" Connecting to database...")
    db_module = DBModule()
    cameras = db_module.fetch_all_cameras()

    if not cameras:
        logger.warning("No cameras found in the database. Exiting.")
        return

    # Get max cameras from config
    max_cameras = config.getint('MODULE', 'cameras', 4)
    if len(cameras) > max_cameras:
        cameras = cameras[:max_cameras]

    logger.info(f" Loaded {len(cameras)} cameras from database")

    # Initialize video recorder if enabled
    video_recording_enabled = config.getint('VIDEO_RECORDING', 'enable', 1)
    if video_recording_enabled:
        logger.info(" Initializing video recorder...")
        video_recorder = None

    else:
        video_recorder = None
        logger.info(" Video recording disabled")


    camera_names = {}
    rtsp_list = []
    roi_dict = {}

    for idx, cam in enumerate(cameras):
        camera_names[idx] = cam['Camera_Name']
        rtsp_list.append(cam.get('URL', ''))

        # Fetch ROI from database
        roi_points = db_module.get_roi_by_camera_id(cam['Camera_Id'])
        if roi_points:
            roi_dict[cam['Camera_Name']] = roi_points


    initialize_enabled_classes(camera_names, db_module)
    print_configuration()

    # Create frame queues
    num_cameras = len(cameras)
    queue_size = config.getint('QUEUE', 'cam_queue', 3)
    from queue import Queue
    camera_frame_queues = [Queue(maxsize=queue_size) for _ in range(num_cameras)]

    # Register queues with memory manager
    for queue in camera_frame_queues:
        memory_manager.register_frame_queue(queue)


    multi_cam_manager = MultiCamCameraManager(rtsp_urls=rtsp_list)
    multi_cam_manager.start_all_cameras()

    # Register camera managers
    for cam_id, cam_manager in multi_cam_manager.camera_managers.items():
        memory_manager.register_camera_manager(cam_manager)


    detection_manager = MultiCameraDetectionManager(
        multi_cam_manager.camera_managers,
        model_path="yolo11m.pt",
        roi_dict=roi_dict,
        camera_names=camera_names
    )

    for det_manager in detection_manager.get_detection_managers().values():
        memory_manager.register_detection_manager(det_manager)

    logger.info(" Detection managers initialized")


    detection_thread = threading.Thread(target=detection_manager.start, daemon=True)
    detection_thread.start()


    tracking_manager = MultiCameraTrackingManager(
        multi_cam_manager.camera_managers,
        db_module=db_module,
        camera_names=camera_names,
        camera_frame_queues=camera_frame_queues,
        roi_dict=roi_dict,
        video_recorder=video_recorder
    )

    for track_manager in tracking_manager.get_tracking_managers():
        memory_manager.register_tracking_manager(track_manager)

    logger.info(" Tracking managers initialized")

    manager = TrackVideoManager(
        base_folder=r"E:\Zone_Intrusion_Service\frame_data_storage",
        output_folder=r"D:\ZONE_DATA\ZONE_VIDEOS",
        fps=10,
        max_age_hours=24,
        cleanup_interval=60,
        scan_interval=2,  # Check for new files every 2 seconds
        min_frames_for_video=1  # Minimum frames to create video
    )

    tracker = threading.Thread(target=tracking_manager.start_all_tracking, daemon=True)
    tracker.start()

    # Start memory management
    memory_manager.start_automatic_cleanup()


    # Main loop
    try:
        frame_count = 0
        last_status_log = time.time()
        status_log_interval = config.getint('MAIN_LOOP', 'status_log_interval', 60)
        main_loop_sleep = config.getint('MAIN_LOOP', 'sleep_interval', 10)
        memory_cleanup_interval = config.getint('MAIN_LOOP', 'memory_cleanup_interval', 30)


        while True:
            time.sleep(main_loop_sleep)
            frame_count += 1
            watchdog.send_signal()

            # Handle watchdog messages
            if watchdog.last_msg == "Policy":
                reload_enabled_classes(camera_names, db_module)
                for camera_name, manager in detection_manager.detection_managers.items():
                    manager.enabled_classes_cache = manager._get_enabled_classes()
                watchdog.last_msg = ""

            if watchdog.last_msg == "Stop":
                logger.info(" Stop signal received from watchdog")
                sys.exit(0)

            # Periodic cleanup
            if frame_count % memory_cleanup_interval == 0:
                memory_manager.manual_cleanup()

            # Status logging
            current_time = time.time()
            if current_time - last_status_log >= status_log_interval:
                active_cams = len(multi_cam_manager.camera_managers)

                if video_recording_enabled and video_recorder:
                    active_recordings = video_recorder.get_active_recordings_count()
                else:
                    print(f" Status: Cameras: {active_cams}")

                last_status_log = current_time

    except KeyboardInterrupt:

        stop_time = time.time()
        stop_datetime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(stop_time))
        runtime_seconds = stop_time - start_time
        runtime_hours = int(runtime_seconds // 3600)
        runtime_minutes = int((runtime_seconds % 3600) // 60)
        runtime_secs = int(runtime_seconds % 60)

        logger.info(f" Total runtime: {runtime_hours}h {runtime_minutes}m {runtime_secs}s")
        logger.info(f"Stopped at: {stop_datetime}")

        memory_manager.stop_automatic_cleanup()

        multi_cam_manager.stop_all_cameras()


    except Exception as e:

        raise


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Application terminated with error: {e}")
        input("Press Enter to exit...")
    finally:
        logging.info("Application terminated")